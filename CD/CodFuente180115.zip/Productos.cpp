#include "Productos.h"
#include <fstream>
#include <cstring>
#include <string>
using namespace std;

Productos::Productos( string nom,int cod,int prec) {
	nomb=nom;
	codi=cod;
	preci=prec;
}
void Productos::leerproducto(ifstream &stocks){
	stock p;
	stocks.read((char*)&p,sizeof (p));
	nomb=p.nombre;
	codi=p.codigo;
	preci=p.precio;
}
void Productos::guardarproductos(ofstream &stocks){
	stock g;
	strcpy(g.nombre,nomb.c_str());
	g.codigo=codi;
	g.precio=preci;
	stocks.write((char*)&g,sizeof (g));
}


Productos::~Productos() {
	nomb="";
	codi=0;
	preci=0;
}

