#ifndef EDITMESAS_H
#define EDITMESAS_H
#include "Ventanas.h"

class EditMesas : public MyDialog6 {
	
private:
	
protected:
	void onAceptar( wxCommandEvent& event ) ;
	void onCancelar( wxCommandEvent& event ) ;
	
public:
	EditMesas(wxWindow *parent=NULL);
	~EditMesas();
};

#endif
