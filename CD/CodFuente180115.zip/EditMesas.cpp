#include "EditMesas.h"
#include <fstream>
#include <wx/msgdlg.h>
#include "Bar.h"
#include <wx/icon.h>
using namespace std;

EditMesas::EditMesas(wxWindow *parent) : MyDialog6(parent) {
	SetIcon(wxIcon("logo.ico"));
	int val = mi_bar->LeerMesasInicial();
	m_spinCtrl2->SetValue(val);
	m_spinCtrl2->SetFocus();
}

EditMesas::~EditMesas() {
	
}

void EditMesas::onAceptar( wxCommandEvent& event )  {
	int val = m_spinCtrl2->GetValue();
	if (val<1||val>48){
		wxMessageBox("Ingrese una cantidad v�lida (1..48)","Error en la cantidad de mesas");
		m_spinCtrl2->SetFocus();
	}
	else{
		mi_bar->GuardarMesasInicial(val);
		Close();
	}
}

void EditMesas::onCancelar( wxCommandEvent& event )  {
	Close();
}

