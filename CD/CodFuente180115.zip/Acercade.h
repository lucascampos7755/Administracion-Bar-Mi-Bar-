#ifndef ACERCADE_H
#define ACERCADE_H
#include "Ventanas.h"

class Acercade : public MyDialog5 {
	
private:
	
protected:
	
public:
	Acercade(wxWindow *parent=NULL);
	~Acercade();
};

#endif

