#include "Application.h"
#include "VentanaPrincipal1.h"
#include <wx/image.h>
#include "Bar.h"
#include <wx/splash.h>
#include <wx/bitmap.h>


bool mxApplication::OnInit() {
	wxImage::AddHandler(new wxPNGHandler);
	wxImage::AddHandler(new wxXPMHandler);
	wxImage::AddHandler(new wxJPEGHandler);
	wxImage::AddHandler(new wxBMPHandler);
	wxBitmap bitmap;
	if (bitmap.LoadFile("splash.png", wxBITMAP_TYPE_PNG)){
		wxSplashScreen* splash = new wxSplashScreen(bitmap, wxSPLASH_CENTRE_ON_SCREEN|wxSPLASH_TIMEOUT, 6000, NULL, -1, wxDefaultPosition, wxDefaultSize, wxBORDER_SIMPLE|wxSTAY_ON_TOP);
	}
	wxYield();
    mi_bar = new Bar("Productos.dat","Total.dat");
	new VentanaPrincipal1(NULL);
	return true;
}
