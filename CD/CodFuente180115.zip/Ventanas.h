///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Sep  8 2010)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#ifndef __Ventanas__
#define __Ventanas__

#include <wx/colour.h>
#include <wx/settings.h>
#include <wx/string.h>
#include <wx/font.h>
#include <wx/grid.h>
#include <wx/gdicmn.h>
#include <wx/sizer.h>
#include <wx/button.h>
#include <wx/stattext.h>
#include <wx/dialog.h>
#include <wx/textctrl.h>
#include <wx/radiobut.h>
#include <wx/spinctrl.h>
#include <wx/frame.h>
#include <wx/listbox.h>
#include <wx/html/htmlwin.h>

///////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
/// Class MyDialog21
///////////////////////////////////////////////////////////////////////////////
class MyDialog21 : public wxDialog 
{
	private:
	
	protected:
		wxGrid* Factura;
		wxButton* m_button20;
		wxButton* m_button19;
		wxStaticText* m_staticText3;
		wxStaticText* Va_Precio;
		wxButton* m_button18;
		
		// Virtual event handlers, overide them in your derived class
		virtual void BotonAgregar( wxCommandEvent& event ) { event.Skip(); }
		virtual void BotonQuitar( wxCommandEvent& event ) { event.Skip(); }
		virtual void ClickOnImprimir( wxCommandEvent& event ) { event.Skip(); }
		
	
	public:
		
		MyDialog21( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Mesa x"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 680,400 ), long style = wxCLOSE_BOX|wxDEFAULT_DIALOG_STYLE );
		~MyDialog21();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class MyDialog3
///////////////////////////////////////////////////////////////////////////////
class MyDialog3 : public wxDialog 
{
	private:
	
	protected:
		wxStaticText* m_staticText8;
		wxTextCtrl* m_textCtrl11;
		wxRadioButton* m_radioBtn1;
		wxRadioButton* m_radioBtn2;
		wxStaticText* m_staticText7;
		wxSpinCtrl* m_spinCtrl1;
		wxButton* m_button21;
		wxGrid* m_grid31;
		
		// Virtual event handlers, overide them in your derived class
		virtual void init( wxInitDialogEvent& event ) { event.Skip(); }
		virtual void BusqEnter( wxCommandEvent& event ) { event.Skip(); }
		virtual void SelProducto( wxCommandEvent& event ) { event.Skip(); }
		virtual void SelCodigo( wxCommandEvent& event ) { event.Skip(); }
		virtual void Buscar( wxCommandEvent& event ) { event.Skip(); }
		virtual void OnLeftDClick( wxGridEvent& event ) { event.Skip(); }
		virtual void tecla( wxKeyEvent& event ) { event.Skip(); }
		
	
	public:
		
		MyDialog3( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Agregar Producto"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 455,239 ), long style = wxDEFAULT_DIALOG_STYLE );
		~MyDialog3();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class MyDialog4
///////////////////////////////////////////////////////////////////////////////
class MyDialog4 : public wxDialog 
{
	private:
	
	protected:
		wxButton* m_button17;
		wxButton* m_button18;
		wxButton* m_button19;
		wxStaticText* m_staticText4;
		wxTextCtrl* m_textCtrl4;
		wxRadioButton* m_radioBtn5;
		wxRadioButton* m_radioBtn6;
		wxButton* m_button20;
		wxGrid* m_grid30;
		
		// Virtual event handlers, overide them in your derived class
		virtual void AgregarProductos( wxCommandEvent& event ) { event.Skip(); }
		virtual void Modifica( wxCommandEvent& event ) { event.Skip(); }
		virtual void Eliminar( wxCommandEvent& event ) { event.Skip(); }
		virtual void Enterlbl( wxCommandEvent& event ) { event.Skip(); }
		virtual void SelProducto( wxCommandEvent& event ) { event.Skip(); }
		virtual void SelCodigo( wxCommandEvent& event ) { event.Skip(); }
		virtual void Buscar( wxCommandEvent& event ) { event.Skip(); }
		virtual void dblClic( wxGridEvent& event ) { event.Skip(); }
		
	
	public:
		
		MyDialog4( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Cargado de Productos"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 650,600 ), long style = wxDEFAULT_DIALOG_STYLE );
		~MyDialog4();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class MyDialog2
///////////////////////////////////////////////////////////////////////////////
class MyDialog2 : public wxDialog 
{
	private:
	
	protected:
		wxStaticText* m_staticText7;
		wxTextCtrl* m_textCtrl6;
		wxStaticText* m_staticText10;
		wxTextCtrl* m_textCtrl9;
		wxStaticText* m_staticText11;
		wxTextCtrl* m_textCtrl10;
		wxButton* m_button22;
		wxButton* m_button23;
		
		// Virtual event handlers, overide them in your derived class
		virtual void Aceptar( wxCommandEvent& event ) { event.Skip(); }
		virtual void Cancelar( wxCommandEvent& event ) { event.Skip(); }
		
	
	public:
		
		MyDialog2( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Ingrese producto"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 300,175 ), long style = wxDEFAULT_DIALOG_STYLE );
		~MyDialog2();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class Frame0
///////////////////////////////////////////////////////////////////////////////
class Frame0 : public wxFrame 
{
	private:
	
	protected:
		wxButton* m_button85;
		wxButton* m_button12;
		wxButton* m_button10;
		wxButton* m_button13;
		wxButton* m_button14;
		wxButton* m_button15;
		wxButton* m_button16;
		wxGridSizer* gSizer1;
		wxButton* m_button7;
		
		// Virtual event handlers, overide them in your derived class
		virtual void OnCerrar( wxCloseEvent& event ) { event.Skip(); }
		virtual void AgregarMesa( wxCommandEvent& event ) { event.Skip(); }
		virtual void onMesasEdit( wxMouseEvent& event ) { event.Skip(); }
		virtual void VerCaja( wxCommandEvent& event ) { event.Skip(); }
		virtual void Agrega( wxCommandEvent& event ) { event.Skip(); }
		virtual void VerHistorial( wxCommandEvent& event ) { event.Skip(); }
		virtual void onAyuda( wxCommandEvent& event ) { event.Skip(); }
		virtual void VerAcercaDe( wxCommandEvent& event ) { event.Skip(); }
		virtual void CerrarSesion( wxCommandEvent& event ) { event.Skip(); }
		virtual void AbrirMesa( wxCommandEvent& event ) { event.Skip(); }
		
	
	public:
		
		Frame0( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Mi Bar 1.0.0.01"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 800,600 ), long style = wxCLOSE_BOX|wxDEFAULT_FRAME_STYLE|wxTAB_TRAVERSAL );
		~Frame0();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class MyDialog6
///////////////////////////////////////////////////////////////////////////////
class MyDialog6 : public wxDialog 
{
	private:
	
	protected:
		
		wxSpinCtrl* m_spinCtrl2;
		wxStaticText* m_staticText121;
		
		wxStaticText* m_staticText12;
		
		wxButton* m_button19;
		
		wxButton* m_button20;
		
		// Virtual event handlers, overide them in your derived class
		virtual void onAceptar( wxCommandEvent& event ) { event.Skip(); }
		virtual void onCancelar( wxCommandEvent& event ) { event.Skip(); }
		
	
	public:
		
		MyDialog6( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Cantidad inicial de mesas"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 300,141 ), long style = wxDEFAULT_DIALOG_STYLE );
		~MyDialog6();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class MyDialog5
///////////////////////////////////////////////////////////////////////////////
class MyDialog5 : public wxDialog 
{
	private:
	
	protected:
		wxStaticText* m_staticText9;
		wxStaticText* m_staticText10;
		wxStaticText* m_staticText13;
	
	public:
		
		MyDialog5( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Acerca de"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 200,136 ), long style = wxDEFAULT_DIALOG_STYLE );
		~MyDialog5();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class MyDialog7
///////////////////////////////////////////////////////////////////////////////
class MyDialog7 : public wxDialog 
{
	private:
	
	protected:
		wxGrid* m_grid4;
		wxStaticText* m_staticText15;
		wxTextCtrl* m_textCtrl7;
		wxButton* m_button21;
		
		// Virtual event handlers, overide them in your derived class
		virtual void VerFac( wxGridEvent& event ) { event.Skip(); }
		virtual void CambiarCaja( wxCommandEvent& event ) { event.Skip(); }
		
	
	public:
		
		MyDialog7( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Caja"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 364,400 ), long style = wxDEFAULT_DIALOG_STYLE );
		~MyDialog7();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class MyDialog8
///////////////////////////////////////////////////////////////////////////////
class MyDialog8 : public wxDialog 
{
	private:
	
	protected:
		wxStaticText* m_staticText17;
		wxListBox* m_listBox1;
		wxStaticText* m_staticText18;
		wxGrid* m_grid8;
		
		// Virtual event handlers, overide them in your derived class
		virtual void FechaElegida( wxCommandEvent& event ) { event.Skip(); }
		virtual void VerFac( wxGridEvent& event ) { event.Skip(); }
		
	
	public:
		
		MyDialog8( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Historial de Caja"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 501,335 ), long style = wxDEFAULT_DIALOG_STYLE );
		~MyDialog8();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class MyDialog9
///////////////////////////////////////////////////////////////////////////////
class MyDialog9 : public wxDialog 
{
	private:
	
	protected:
		wxHtmlWindow* m_htmlWin1;
		wxButton* m_button22;
		
		// Virtual event handlers, overide them in your derived class
		virtual void onImprimir( wxCommandEvent& event ) { event.Skip(); }
		
	
	public:
		
		MyDialog9( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Visor de Facturas"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 600,500 ), long style = wxDEFAULT_DIALOG_STYLE );
		~MyDialog9();
	
};

#endif //__Ventanas__
