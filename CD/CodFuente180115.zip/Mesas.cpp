#include "Mesas.h"
#include <cstring>
#include <vector>
#include <wx/msgdlg.h>
#include "Funciones.h"
using namespace std;

Mesas::Mesas(string identificacion) {
	SetSize(0);
	identi=identificacion;
	ocupada=false;
}

void Mesas::agregaproductos(int cod,int cant){
	ventas.push_back(make_pair(cod,cant));
}

void Mesas::eliminaproducto(int pos){
	ventas.erase(ventas.begin()+pos);
}

Mesas::~Mesas() {
	
}

int Mesas::cantitems ( ) {
	return ventas.size();
}

void Mesas::SetSize (int n) {
	ventas.resize(n);
}

