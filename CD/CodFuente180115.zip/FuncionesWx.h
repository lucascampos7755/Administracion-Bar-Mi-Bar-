#ifndef FUNCIONESWX_H
#define FUNCIONESWX_H
#include <string>
#include <wx/grid.h>
#include <wx/string.h>
using namespace std;

//Aqu� ponemos las funciones que realizan acciones las cuales no podemos realizarlas
//sin la ayuda de la interfaz.

bool PrintFac(string nomarch); //Abre nomarch (txt) lo formatea a html y muestra el dialogo de imprimir
void ErroresPrint(int ret); //Errores al imprimir
void ClearGrid(wxGrid &grid);//Elimina de la grilla las filas con primer y segundo campo vac�os.


#endif
