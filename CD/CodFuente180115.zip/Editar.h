#ifndef EDITAR_H
#define EDITAR_H
#include "Ventanas.h"
#include "Editar.h"
#include <wx/window.h>

class Editar : public MyDialog2 {
	
private:
	int l;
protected:
	void BotonAgregar( wxCommandEvent& event ) ;
	void BotonQuitar( wxCommandEvent& event ) ;
	void ClickOnImprimir( wxCommandEvent& event ) ;
	void Aceptar( wxCommandEvent& event ) ;
	void Cancelar( wxCommandEvent& event ) ;
public:
	Editar(wxWindow *parent=NULL, int p=0);
	~Editar();
};

#endif

