#ifndef BAR_H
#define BAR_H
#include <string>
#include <vector>
#include "Productos.h"
#include "Mesas.h"
#include "Caja.h"
#include "Total.h"
#include <list>
using namespace std;

class Bar {
private:
	friend class VentanaAgregar;
	friend class VentanaMesas;
	vector<Mesas> consumo;
	vector<Productos> cantidad;
	vector<Total> total2;
	string nombre_archivoproductos,nombre_archivomesas;
	bool cerrada; //estado de la caja
protected:
public:
	Bar(){};
	~Bar();
	Bar(string nombreproductos,string neto);
	bool Guardar();//Guarda en Productos.dat y Total.dat los datos alojados en los vectores
	int CantidadDeProductos();//Size de cantidad
	int CantidadDeMesas();//Size de consumo
	int CantidadFacturas();//Size de total2
	void AgregarProductos(Productos &p);//Agrega p a cantidad
	Productos &operator[](int i);//Devuelve el elemento i de cantidad
	void OrdenaAlf();
	int Buscarpos(string nom);//Buscar posici�n por nombre
	int Buscarposc(int cod);//Buscar posici�n por c�digo
	void EliminarProd(int pos);
	int GetNewFacCod(int cod=0);
	int SugerirCodigo();//Sugiero un codigo para el proximo producto (el prox num libre)
	Total elemCaja(int i);
	bool CajaCerrada();
	void AbrirCaja();
	void CerrarCaja();
	void CambiarCaja();
	string GetTotalUnFac();//Devuelve el total ($) de facturas sin cerar
	list<string> FechasHistorial();//Devuelve las fechas validas para seleccionar en el historial
	list<q> FiltrarCerradas(string fecha);
	int HacerFacturaHTML(string fecha,string hora);//genera en /facturas/1.html la factura.
	int HacerFacturaHTML (string nomarch);
	int  LeerMesasInicial();
	void GuardarMesasInicial(int val);
	int AgregarMesa();//incrementa en uno la cant de mesas y devuelve el size;
	vector<Productos> BuscarPorNombre(string busq);//M�todos para buscar productos
	vector<Productos> BuscarPorCodigo(string busq);
	vector<m> RecupMesa(int table);//teniendo solo un vector de pares (codigo y cantidad) obtengo un vector con codigo detalle precio cantidad total
	int GetTotalMesa(int table);//Calcula el precio total de una mesa
	bool MesasSinFacturar();//True si alguna mesa est� sin facturar 
	bool MesasOcupadas();//True si alguna mesa est� ocupada
	void AddItem(int table,int cod,int cant); //Ingresa cant unidades de cod en mesa.
	void RemoveItem(int mesa,int i);//Elimina el elemento i del vector de pedidos de mesa.
	int GetItemCount(int mesa);//Devuelve cantidad de items en la factura
	string CrearFactura(int table);//Genera el .txt en /facturas
	void VaciarMesa(int table);
	void OcuparMesa(int table);
	void DesocuparMesa(int table);
	void DesocuparTodas();
	bool MesaSinVentas(int table);
	bool AbrirAyuda();
	bool YaExisteProd(string busq); //True si encuentra el codigo en productos
};
extern Bar *mi_bar;

#endif

