///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Sep  8 2010)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "Ventanas.h"

///////////////////////////////////////////////////////////////////////////

MyDialog21::MyDialog21( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxSize( 680,400 ), wxSize( 680,-1 ) );
	this->SetBackgroundColour( wxColour( 105, 189, 214 ) );
	
	wxBoxSizer* bSizer3;
	bSizer3 = new wxBoxSizer( wxVERTICAL );
	
	wxBoxSizer* bSizer7;
	bSizer7 = new wxBoxSizer( wxHORIZONTAL );
	
	Factura = new wxGrid( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 0 );
	
	// Grid
	Factura->CreateGrid( 1, 5 );
	Factura->EnableEditing( false );
	Factura->EnableGridLines( true );
	Factura->SetGridLineColour( wxSystemSettings::GetColour( wxSYS_COLOUR_HIGHLIGHT ) );
	Factura->EnableDragGridSize( false );
	Factura->SetMargins( 0, 0 );
	
	// Columns
	Factura->SetColSize( 0, 100 );
	Factura->SetColSize( 1, 260 );
	Factura->SetColSize( 2, 100 );
	Factura->SetColSize( 3, 100 );
	Factura->SetColSize( 4, 100 );
	Factura->EnableDragColMove( true );
	Factura->EnableDragColSize( true );
	Factura->SetColLabelSize( 30 );
	Factura->SetColLabelValue( 0, wxT("Codigo") );
	Factura->SetColLabelValue( 1, wxT("Detalle") );
	Factura->SetColLabelValue( 2, wxT("Cantidad") );
	Factura->SetColLabelValue( 3, wxT("Precio Unitario") );
	Factura->SetColLabelValue( 4, wxT("Total") );
	Factura->SetColLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Rows
	Factura->EnableDragRowSize( true );
	Factura->SetRowLabelSize( 0 );
	Factura->SetRowLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Label Appearance
	Factura->SetLabelFont( wxFont( 8, 74, 90, 92, false, wxT("Tahoma") ) );
	
	// Cell Defaults
	Factura->SetDefaultCellFont( wxFont( wxNORMAL_FONT->GetPointSize(), 70, 90, 90, false, wxT("@Arial Unicode MS") ) );
	Factura->SetDefaultCellAlignment( wxALIGN_LEFT, wxALIGN_TOP );
	bSizer7->Add( Factura, 1, wxALL|wxEXPAND, 5 );
	
	bSizer3->Add( bSizer7, 1, wxEXPAND, 5 );
	
	wxGridSizer* gSizer2;
	gSizer2 = new wxGridSizer( 0, 2, 0, 0 );
	
	wxBoxSizer* bSizer25;
	bSizer25 = new wxBoxSizer( wxHORIZONTAL );
	
	m_button20 = new wxButton( this, wxID_ANY, wxT("Agregar"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer25->Add( m_button20, 0, wxALL, 5 );
	
	m_button19 = new wxButton( this, wxID_ANY, wxT("Quitar"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer25->Add( m_button19, 0, wxALL, 5 );
	
	gSizer2->Add( bSizer25, 1, wxEXPAND, 5 );
	
	wxBoxSizer* bSizer24;
	bSizer24 = new wxBoxSizer( wxHORIZONTAL );
	
	m_staticText3 = new wxStaticText( this, wxID_ANY, wxT("Total :"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText3->Wrap( -1 );
	bSizer24->Add( m_staticText3, 0, wxALIGN_RIGHT|wxALIGN_CENTER_VERTICAL|wxRIGHT, 5 );
	
	Va_Precio = new wxStaticText( this, wxID_ANY, wxT("va precio"), wxDefaultPosition, wxSize( 90,-1 ), 0 );
	Va_Precio->Wrap( -1 );
	Va_Precio->SetForegroundColour( wxSystemSettings::GetColour( wxSYS_COLOUR_BTNTEXT ) );
	Va_Precio->SetBackgroundColour( wxSystemSettings::GetColour( wxSYS_COLOUR_INFOBK ) );
	
	bSizer24->Add( Va_Precio, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5 );
	
	m_button18 = new wxButton( this, wxID_ANY, wxT("Imprimir factura"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer24->Add( m_button18, 0, wxALL, 5 );
	
	gSizer2->Add( bSizer24, 0, wxALIGN_RIGHT, 5 );
	
	bSizer3->Add( gSizer2, 0, wxEXPAND, 5 );
	
	this->SetSizer( bSizer3 );
	this->Layout();
	
	this->Centre( wxBOTH );
	
	// Connect Events
	m_button20->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog21::BotonAgregar ), NULL, this );
	m_button19->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog21::BotonQuitar ), NULL, this );
	m_button18->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog21::ClickOnImprimir ), NULL, this );
}

MyDialog21::~MyDialog21()
{
	// Disconnect Events
	m_button20->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog21::BotonAgregar ), NULL, this );
	m_button19->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog21::BotonQuitar ), NULL, this );
	m_button18->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog21::ClickOnImprimir ), NULL, this );
	
}

MyDialog3::MyDialog3( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	
	wxBoxSizer* bSizer26;
	bSizer26 = new wxBoxSizer( wxVERTICAL );
	
	wxBoxSizer* bSizer27;
	bSizer27 = new wxBoxSizer( wxHORIZONTAL );
	
	m_staticText8 = new wxStaticText( this, wxID_ANY, wxT("Buscar"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText8->Wrap( -1 );
	bSizer27->Add( m_staticText8, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	m_textCtrl11 = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_PROCESS_ENTER );
	m_textCtrl11->SetMaxLength( 25 ); 
	bSizer27->Add( m_textCtrl11, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	wxBoxSizer* bSizer28;
	bSizer28 = new wxBoxSizer( wxVERTICAL );
	
	m_radioBtn1 = new wxRadioButton( this, wxID_ANY, wxT("Producto"), wxDefaultPosition, wxDefaultSize, 0 );
	m_radioBtn1->SetValue( true ); 
	bSizer28->Add( m_radioBtn1, 0, wxALL, 5 );
	
	m_radioBtn2 = new wxRadioButton( this, wxID_ANY, wxT("Codigo"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer28->Add( m_radioBtn2, 0, wxALL, 5 );
	
	bSizer27->Add( bSizer28, 1, 0, 5 );
	
	m_staticText7 = new wxStaticText( this, wxID_ANY, wxT("Cantidad"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText7->Wrap( -1 );
	bSizer27->Add( m_staticText7, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	m_spinCtrl1 = new wxSpinCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 50,-1 ), wxSP_ARROW_KEYS, 1, 99, 1 );
	bSizer27->Add( m_spinCtrl1, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	m_button21 = new wxButton( this, wxID_ANY, wxT("Buscar"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer27->Add( m_button21, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	bSizer26->Add( bSizer27, 0, wxEXPAND, 5 );
	
	m_grid31 = new wxGrid( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 0 );
	
	// Grid
	m_grid31->CreateGrid( 0, 2 );
	m_grid31->EnableEditing( false );
	m_grid31->EnableGridLines( true );
	m_grid31->EnableDragGridSize( false );
	m_grid31->SetMargins( 0, 0 );
	
	// Columns
	m_grid31->SetColSize( 0, 80 );
	m_grid31->SetColSize( 1, 355 );
	m_grid31->SetColSize( 2, 80 );
	m_grid31->SetColSize( 3, 80 );
	m_grid31->EnableDragColMove( false );
	m_grid31->EnableDragColSize( false );
	m_grid31->SetColLabelSize( 30 );
	m_grid31->SetColLabelValue( 0, wxT("Codigo") );
	m_grid31->SetColLabelValue( 1, wxT("Producto") );
	m_grid31->SetColLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Rows
	m_grid31->EnableDragRowSize( true );
	m_grid31->SetRowLabelSize( 0 );
	m_grid31->SetRowLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Label Appearance
	
	// Cell Defaults
	m_grid31->SetDefaultCellAlignment( wxALIGN_LEFT, wxALIGN_TOP );
	bSizer26->Add( m_grid31, 1, wxALL|wxEXPAND, 5 );
	
	this->SetSizer( bSizer26 );
	this->Layout();
	
	this->Centre( wxBOTH );
	
	// Connect Events
	this->Connect( wxEVT_INIT_DIALOG, wxInitDialogEventHandler( MyDialog3::init ) );
	m_textCtrl11->Connect( wxEVT_COMMAND_TEXT_ENTER, wxCommandEventHandler( MyDialog3::BusqEnter ), NULL, this );
	m_radioBtn1->Connect( wxEVT_COMMAND_RADIOBUTTON_SELECTED, wxCommandEventHandler( MyDialog3::SelProducto ), NULL, this );
	m_radioBtn2->Connect( wxEVT_COMMAND_RADIOBUTTON_SELECTED, wxCommandEventHandler( MyDialog3::SelCodigo ), NULL, this );
	m_button21->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog3::Buscar ), NULL, this );
	m_grid31->Connect( wxEVT_GRID_CELL_LEFT_DCLICK, wxGridEventHandler( MyDialog3::OnLeftDClick ), NULL, this );
	m_grid31->Connect( wxEVT_KEY_DOWN, wxKeyEventHandler( MyDialog3::tecla ), NULL, this );
}

MyDialog3::~MyDialog3()
{
	// Disconnect Events
	this->Disconnect( wxEVT_INIT_DIALOG, wxInitDialogEventHandler( MyDialog3::init ) );
	m_textCtrl11->Disconnect( wxEVT_COMMAND_TEXT_ENTER, wxCommandEventHandler( MyDialog3::BusqEnter ), NULL, this );
	m_radioBtn1->Disconnect( wxEVT_COMMAND_RADIOBUTTON_SELECTED, wxCommandEventHandler( MyDialog3::SelProducto ), NULL, this );
	m_radioBtn2->Disconnect( wxEVT_COMMAND_RADIOBUTTON_SELECTED, wxCommandEventHandler( MyDialog3::SelCodigo ), NULL, this );
	m_button21->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog3::Buscar ), NULL, this );
	m_grid31->Disconnect( wxEVT_GRID_CELL_LEFT_DCLICK, wxGridEventHandler( MyDialog3::OnLeftDClick ), NULL, this );
	m_grid31->Disconnect( wxEVT_KEY_DOWN, wxKeyEventHandler( MyDialog3::tecla ), NULL, this );
	
}

MyDialog4::MyDialog4( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxSize( 650,600 ), wxSize( 650,600 ) );
	
	wxBoxSizer* bSizer12;
	bSizer12 = new wxBoxSizer( wxHORIZONTAL );
	
	wxBoxSizer* bSizer13;
	bSizer13 = new wxBoxSizer( wxVERTICAL );
	
	m_button17 = new wxButton( this, wxID_ANY, wxT("Agregar"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer13->Add( m_button17, 0, wxALL, 5 );
	
	m_button18 = new wxButton( this, wxID_ANY, wxT("Modificar"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer13->Add( m_button18, 0, wxALL, 5 );
	
	m_button19 = new wxButton( this, wxID_ANY, wxT("Eliminar"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer13->Add( m_button19, 0, wxALL, 5 );
	
	bSizer12->Add( bSizer13, 0, wxEXPAND, 5 );
	
	wxBoxSizer* bSizer14;
	bSizer14 = new wxBoxSizer( wxVERTICAL );
	
	wxBoxSizer* bSizer16;
	bSizer16 = new wxBoxSizer( wxHORIZONTAL );
	
	m_staticText4 = new wxStaticText( this, wxID_ANY, wxT("Producto"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText4->Wrap( -1 );
	bSizer16->Add( m_staticText4, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	m_textCtrl4 = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_PROCESS_ENTER );
	m_textCtrl4->SetMaxLength( 25 ); 
	bSizer16->Add( m_textCtrl4, 1, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	wxBoxSizer* bSizer28;
	bSizer28 = new wxBoxSizer( wxVERTICAL );
	
	m_radioBtn5 = new wxRadioButton( this, wxID_ANY, wxT("Nombre"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer28->Add( m_radioBtn5, 0, wxALL, 5 );
	
	m_radioBtn6 = new wxRadioButton( this, wxID_ANY, wxT("C�digo"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer28->Add( m_radioBtn6, 0, wxALL, 5 );
	
	bSizer16->Add( bSizer28, 0, wxEXPAND, 5 );
	
	m_button20 = new wxButton( this, wxID_ANY, wxT("Buscar"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer16->Add( m_button20, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	bSizer14->Add( bSizer16, 0, wxEXPAND, 5 );
	
	wxBoxSizer* bSizer18;
	bSizer18 = new wxBoxSizer( wxVERTICAL );
	
	m_grid30 = new wxGrid( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 0 );
	
	// Grid
	m_grid30->CreateGrid( 0, 3 );
	m_grid30->EnableEditing( false );
	m_grid30->EnableGridLines( true );
	m_grid30->EnableDragGridSize( false );
	m_grid30->SetMargins( 0, 0 );
	
	// Columns
	m_grid30->SetColSize( 0, 80 );
	m_grid30->SetColSize( 1, 355 );
	m_grid30->SetColSize( 2, 80 );
	m_grid30->SetColSize( 3, 80 );
	m_grid30->EnableDragColMove( false );
	m_grid30->EnableDragColSize( false );
	m_grid30->SetColLabelSize( 30 );
	m_grid30->SetColLabelValue( 0, wxT("Codigo") );
	m_grid30->SetColLabelValue( 1, wxT("Producto") );
	m_grid30->SetColLabelValue( 2, wxT("Precio") );
	m_grid30->SetColLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Rows
	m_grid30->EnableDragRowSize( true );
	m_grid30->SetRowLabelSize( 0 );
	m_grid30->SetRowLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Label Appearance
	
	// Cell Defaults
	m_grid30->SetDefaultCellAlignment( wxALIGN_LEFT, wxALIGN_TOP );
	bSizer18->Add( m_grid30, 1, wxALL|wxEXPAND, 5 );
	
	bSizer14->Add( bSizer18, 1, wxEXPAND, 5 );
	
	bSizer12->Add( bSizer14, 1, wxEXPAND, 5 );
	
	this->SetSizer( bSizer12 );
	this->Layout();
	
	this->Centre( wxBOTH );
	
	// Connect Events
	m_button17->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog4::AgregarProductos ), NULL, this );
	m_button18->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog4::Modifica ), NULL, this );
	m_button19->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog4::Eliminar ), NULL, this );
	m_textCtrl4->Connect( wxEVT_COMMAND_TEXT_ENTER, wxCommandEventHandler( MyDialog4::Enterlbl ), NULL, this );
	m_radioBtn5->Connect( wxEVT_COMMAND_RADIOBUTTON_SELECTED, wxCommandEventHandler( MyDialog4::SelProducto ), NULL, this );
	m_radioBtn6->Connect( wxEVT_COMMAND_RADIOBUTTON_SELECTED, wxCommandEventHandler( MyDialog4::SelCodigo ), NULL, this );
	m_button20->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog4::Buscar ), NULL, this );
	m_grid30->Connect( wxEVT_GRID_CELL_LEFT_DCLICK, wxGridEventHandler( MyDialog4::dblClic ), NULL, this );
}

MyDialog4::~MyDialog4()
{
	// Disconnect Events
	m_button17->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog4::AgregarProductos ), NULL, this );
	m_button18->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog4::Modifica ), NULL, this );
	m_button19->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog4::Eliminar ), NULL, this );
	m_textCtrl4->Disconnect( wxEVT_COMMAND_TEXT_ENTER, wxCommandEventHandler( MyDialog4::Enterlbl ), NULL, this );
	m_radioBtn5->Disconnect( wxEVT_COMMAND_RADIOBUTTON_SELECTED, wxCommandEventHandler( MyDialog4::SelProducto ), NULL, this );
	m_radioBtn6->Disconnect( wxEVT_COMMAND_RADIOBUTTON_SELECTED, wxCommandEventHandler( MyDialog4::SelCodigo ), NULL, this );
	m_button20->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog4::Buscar ), NULL, this );
	m_grid30->Disconnect( wxEVT_GRID_CELL_LEFT_DCLICK, wxGridEventHandler( MyDialog4::dblClic ), NULL, this );
	
}

MyDialog2::MyDialog2( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	
	wxBoxSizer* bSizer19;
	bSizer19 = new wxBoxSizer( wxVERTICAL );
	
	wxGridSizer* gSizer3;
	gSizer3 = new wxGridSizer( 0, 2, 0, 0 );
	
	m_staticText7 = new wxStaticText( this, wxID_ANY, wxT("Codigo"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText7->Wrap( -1 );
	gSizer3->Add( m_staticText7, 0, wxALL|wxALIGN_CENTER_VERTICAL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_textCtrl6 = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_textCtrl6->SetMaxLength( 9 ); 
	m_textCtrl6->SetToolTip( wxT("Puede ingresar un c�digo propio o aceptar el c�digo sugerido") );
	
	gSizer3->Add( m_textCtrl6, 0, wxALIGN_CENTER|wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	m_staticText10 = new wxStaticText( this, wxID_ANY, wxT("Producto"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText10->Wrap( -1 );
	gSizer3->Add( m_staticText10, 0, wxALL|wxALIGN_CENTER_VERTICAL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_textCtrl9 = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_textCtrl9->SetMaxLength( 25 ); 
	gSizer3->Add( m_textCtrl9, 2, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5 );
	
	m_staticText11 = new wxStaticText( this, wxID_ANY, wxT("Precio"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText11->Wrap( -1 );
	gSizer3->Add( m_staticText11, 0, wxALL|wxALIGN_CENTER_VERTICAL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_textCtrl10 = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_textCtrl10->SetMaxLength( 9 ); 
	gSizer3->Add( m_textCtrl10, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5 );
	
	m_button22 = new wxButton( this, wxID_ANY, wxT("Aceptar"), wxDefaultPosition, wxDefaultSize, 0 );
	gSizer3->Add( m_button22, 0, wxALL|wxALIGN_RIGHT|wxALIGN_CENTER_VERTICAL, 5 );
	
	m_button23 = new wxButton( this, wxID_CANCEL, wxT("Cancelar"), wxDefaultPosition, wxDefaultSize, 0 );
	gSizer3->Add( m_button23, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	bSizer19->Add( gSizer3, 1, wxEXPAND, 5 );
	
	this->SetSizer( bSizer19 );
	this->Layout();
	
	this->Centre( wxBOTH );
	
	// Connect Events
	m_button22->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog2::Aceptar ), NULL, this );
	m_button23->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog2::Cancelar ), NULL, this );
}

MyDialog2::~MyDialog2()
{
	// Disconnect Events
	m_button22->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog2::Aceptar ), NULL, this );
	m_button23->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog2::Cancelar ), NULL, this );
	
}

Frame0::Frame0( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxFrame( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxSize( 800,600 ), wxSize( 800,600 ) );
	this->SetBackgroundColour( wxSystemSettings::GetColour( wxSYS_COLOUR_BTNFACE ) );
	
	wxBoxSizer* bSizer1;
	bSizer1 = new wxBoxSizer( wxHORIZONTAL );
	
	wxBoxSizer* bSizer10;
	bSizer10 = new wxBoxSizer( wxVERTICAL );
	
	m_button85 = new wxButton( this, wxID_ANY, wxT("Agregar mesa"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer10->Add( m_button85, 0, wxALL|wxEXPAND, 5 );
	
	m_button12 = new wxButton( this, wxID_ANY, wxT("Caja"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer10->Add( m_button12, 1, wxALL|wxEXPAND, 5 );
	
	m_button10 = new wxButton( this, wxID_ANY, wxT("Productos"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer10->Add( m_button10, 1, wxALL|wxEXPAND, 5 );
	
	m_button13 = new wxButton( this, wxID_ANY, wxT("Historial de caja"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer10->Add( m_button13, 1, wxALL|wxEXPAND, 5 );
	
	m_button14 = new wxButton( this, wxID_ANY, wxT("Ayuda"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer10->Add( m_button14, 1, wxALL|wxEXPAND, 5 );
	
	m_button15 = new wxButton( this, wxID_ANY, wxT("Acerca de..."), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer10->Add( m_button15, 1, wxALL|wxEXPAND, 5 );
	
	m_button16 = new wxButton( this, wxID_ANY, wxT("Salir"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer10->Add( m_button16, 1, wxALL|wxEXPAND, 5 );
	
	bSizer1->Add( bSizer10, 0, wxRIGHT|wxEXPAND, 5 );
	
	wxBoxSizer* bSizer11;
	bSizer11 = new wxBoxSizer( wxVERTICAL );
	
	gSizer1 = new wxGridSizer( 6, 8, 50, 0 );
	
	m_button7 = new wxButton( this, wxID_ANY, wxT("Mesa 1"), wxDefaultPosition, wxSize( -1,30 ), 0 );
	gSizer1->Add( m_button7, 0, wxALIGN_CENTER_VERTICAL|wxALIGN_CENTER_HORIZONTAL|wxALL, 5 );
	
	bSizer11->Add( gSizer1, 0, wxEXPAND, 5 );
	
	bSizer1->Add( bSizer11, 1, wxEXPAND, 5 );
	
	this->SetSizer( bSizer1 );
	this->Layout();
	
	this->Centre( wxBOTH );
	
	// Connect Events
	this->Connect( wxEVT_CLOSE_WINDOW, wxCloseEventHandler( Frame0::OnCerrar ) );
	m_button85->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::AgregarMesa ), NULL, this );
	m_button85->Connect( wxEVT_RIGHT_DCLICK, wxMouseEventHandler( Frame0::onMesasEdit ), NULL, this );
	m_button12->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::VerCaja ), NULL, this );
	m_button10->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::Agrega ), NULL, this );
	m_button13->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::VerHistorial ), NULL, this );
	m_button14->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::onAyuda ), NULL, this );
	m_button15->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::VerAcercaDe ), NULL, this );
	m_button16->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::CerrarSesion ), NULL, this );
	m_button7->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::AbrirMesa ), NULL, this );
}

Frame0::~Frame0()
{
	// Disconnect Events
	this->Disconnect( wxEVT_CLOSE_WINDOW, wxCloseEventHandler( Frame0::OnCerrar ) );
	m_button85->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::AgregarMesa ), NULL, this );
	m_button85->Disconnect( wxEVT_RIGHT_DCLICK, wxMouseEventHandler( Frame0::onMesasEdit ), NULL, this );
	m_button12->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::VerCaja ), NULL, this );
	m_button10->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::Agrega ), NULL, this );
	m_button13->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::VerHistorial ), NULL, this );
	m_button14->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::onAyuda ), NULL, this );
	m_button15->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::VerAcercaDe ), NULL, this );
	m_button16->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::CerrarSesion ), NULL, this );
	m_button7->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame0::AbrirMesa ), NULL, this );
	
}

MyDialog6::MyDialog6( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	
	wxGridSizer* gSizer4;
	gSizer4 = new wxGridSizer( 3, 3, 0, 0 );
	
	
	gSizer4->Add( 0, 0, 1, wxEXPAND, 5 );
	
	m_spinCtrl2 = new wxSpinCtrl( this, wxID_ANY, wxEmptyString, wxPoint( -1,-1 ), wxSize( 50,-1 ), wxSP_ARROW_KEYS, 1, 48, 1 );
	gSizer4->Add( m_spinCtrl2, 0, wxALIGN_CENTER_VERTICAL|wxALL|wxALIGN_RIGHT, 5 );
	
	m_staticText121 = new wxStaticText( this, wxID_ANY, wxT("1..48"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText121->Wrap( -1 );
	gSizer4->Add( m_staticText121, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	
	gSizer4->Add( 0, 0, 1, wxEXPAND, 5 );
	
	m_staticText12 = new wxStaticText( this, wxID_ANY, wxT("(Los cambios se aplicar�n cuando reinicie el programa)"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText12->Wrap( -1 );
	m_staticText12->SetFont( wxFont( 8, 74, 93, 90, false, wxT("Tahoma") ) );
	
	gSizer4->Add( m_staticText12, 0, wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL|wxALL, 5 );
	
	
	gSizer4->Add( 0, 0, 1, wxEXPAND, 5 );
	
	m_button19 = new wxButton( this, wxID_ANY, wxT("Aceptar"), wxDefaultPosition, wxDefaultSize, 0 );
	gSizer4->Add( m_button19, 0, wxALL, 5 );
	
	
	gSizer4->Add( 0, 0, 1, wxEXPAND, 5 );
	
	m_button20 = new wxButton( this, wxID_CANCEL, wxT("Cancelar"), wxDefaultPosition, wxDefaultSize, 0 );
	gSizer4->Add( m_button20, 0, wxALL|wxALIGN_RIGHT, 5 );
	
	this->SetSizer( gSizer4 );
	this->Layout();
	
	// Connect Events
	m_button19->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog6::onAceptar ), NULL, this );
	m_button20->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog6::onCancelar ), NULL, this );
}

MyDialog6::~MyDialog6()
{
	// Disconnect Events
	m_button19->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog6::onAceptar ), NULL, this );
	m_button20->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog6::onCancelar ), NULL, this );
	
}

MyDialog5::MyDialog5( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	
	wxBoxSizer* bSizer17;
	bSizer17 = new wxBoxSizer( wxVERTICAL );
	
	wxBoxSizer* bSizer29;
	bSizer29 = new wxBoxSizer( wxHORIZONTAL );
	
	m_staticText9 = new wxStaticText( this, wxID_ANY, wxT("MiBar v1.0"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText9->Wrap( -1 );
	m_staticText9->SetFont( wxFont( 14, 74, 90, 92, false, wxT("Tahoma") ) );
	
	bSizer29->Add( m_staticText9, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	bSizer17->Add( bSizer29, 1, wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_staticText10 = new wxStaticText( this, wxID_ANY, wxT("Desarrolladores:\n                Lucas Campos\n                Victor Franco Matzkin"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText10->Wrap( -1 );
	bSizer17->Add( m_staticText10, 0, wxALL, 5 );
	
	m_staticText13 = new wxStaticText( this, wxID_ANY, wxT("Versi�n: 18012015"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText13->Wrap( -1 );
	bSizer17->Add( m_staticText13, 0, wxALL|wxALIGN_RIGHT, 5 );
	
	this->SetSizer( bSizer17 );
	this->Layout();
	
	this->Centre( wxBOTH );
}

MyDialog5::~MyDialog5()
{
}

MyDialog7::MyDialog7( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	
	wxBoxSizer* bSizer18;
	bSizer18 = new wxBoxSizer( wxVERTICAL );
	
	wxBoxSizer* bSizer19;
	bSizer19 = new wxBoxSizer( wxVERTICAL );
	
	m_grid4 = new wxGrid( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 0 );
	
	// Grid
	m_grid4->CreateGrid( 0, 5 );
	m_grid4->EnableEditing( false );
	m_grid4->EnableGridLines( true );
	m_grid4->EnableDragGridSize( false );
	m_grid4->SetMargins( 0, 0 );
	
	// Columns
	m_grid4->SetColSize( 0, 50 );
	m_grid4->SetColSize( 1, 43 );
	m_grid4->SetColSize( 2, 90 );
	m_grid4->SetColSize( 3, 84 );
	m_grid4->SetColSize( 4, 69 );
	m_grid4->EnableDragColMove( false );
	m_grid4->EnableDragColSize( true );
	m_grid4->SetColLabelSize( 30 );
	m_grid4->SetColLabelValue( 0, wxT("Hora") );
	m_grid4->SetColLabelValue( 1, wxT("Mesa") );
	m_grid4->SetColLabelValue( 2, wxT("Nro Factura") );
	m_grid4->SetColLabelValue( 3, wxT("Total") );
	m_grid4->SetColLabelValue( 4, wxT("Fecha") );
	m_grid4->SetColLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Rows
	m_grid4->EnableDragRowSize( true );
	m_grid4->SetRowLabelSize( 0 );
	m_grid4->SetRowLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Label Appearance
	
	// Cell Defaults
	m_grid4->SetDefaultCellAlignment( wxALIGN_LEFT, wxALIGN_TOP );
	bSizer19->Add( m_grid4, 1, wxALL|wxEXPAND, 5 );
	
	bSizer18->Add( bSizer19, 1, wxEXPAND, 5 );
	
	wxBoxSizer* bSizer20;
	bSizer20 = new wxBoxSizer( wxHORIZONTAL );
	
	wxBoxSizer* bSizer21;
	bSizer21 = new wxBoxSizer( wxHORIZONTAL );
	
	m_staticText15 = new wxStaticText( this, wxID_ANY, wxT("Caja del d�a:"), wxPoint( -1,-1 ), wxDefaultSize, wxALIGN_RIGHT );
	m_staticText15->Wrap( -1 );
	bSizer21->Add( m_staticText15, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	m_textCtrl7 = new wxTextCtrl( this, wxID_ANY, wxT("0"), wxDefaultPosition, wxDefaultSize, wxTE_READONLY );
	bSizer21->Add( m_textCtrl7, 1, wxALL|wxALIGN_CENTER_VERTICAL|wxEXPAND, 5 );
	
	bSizer20->Add( bSizer21, 1, wxALIGN_CENTER_VERTICAL, 5 );
	
	wxBoxSizer* bSizer22;
	bSizer22 = new wxBoxSizer( wxHORIZONTAL );
	
	m_button21 = new wxButton( this, wxID_ANY, wxT("Abrir Caja"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer22->Add( m_button21, 0, wxALL|wxALIGN_BOTTOM, 5 );
	
	bSizer20->Add( bSizer22, 0, 0, 5 );
	
	bSizer18->Add( bSizer20, 0, wxEXPAND, 5 );
	
	this->SetSizer( bSizer18 );
	this->Layout();
	
	this->Centre( wxBOTH );
	
	// Connect Events
	m_grid4->Connect( wxEVT_GRID_CELL_LEFT_DCLICK, wxGridEventHandler( MyDialog7::VerFac ), NULL, this );
	m_button21->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog7::CambiarCaja ), NULL, this );
}

MyDialog7::~MyDialog7()
{
	// Disconnect Events
	m_grid4->Disconnect( wxEVT_GRID_CELL_LEFT_DCLICK, wxGridEventHandler( MyDialog7::VerFac ), NULL, this );
	m_button21->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog7::CambiarCaja ), NULL, this );
	
}

MyDialog8::MyDialog8( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	
	wxBoxSizer* bSizer34;
	bSizer34 = new wxBoxSizer( wxHORIZONTAL );
	
	wxBoxSizer* bSizer35;
	bSizer35 = new wxBoxSizer( wxVERTICAL );
	
	m_staticText17 = new wxStaticText( this, wxID_ANY, wxT("Cajas Cerradas"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText17->Wrap( -1 );
	bSizer35->Add( m_staticText17, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_listBox1 = new wxListBox( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 0, NULL, 0 ); 
	bSizer35->Add( m_listBox1, 1, wxALL, 5 );
	
	bSizer34->Add( bSizer35, 0, wxEXPAND, 5 );
	
	wxBoxSizer* bSizer36;
	bSizer36 = new wxBoxSizer( wxVERTICAL );
	
	m_staticText18 = new wxStaticText( this, wxID_ANY, wxT("Caja Seleccionada"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText18->Wrap( -1 );
	bSizer36->Add( m_staticText18, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_grid8 = new wxGrid( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 0 );
	
	// Grid
	m_grid8->CreateGrid( 0, 5 );
	m_grid8->EnableEditing( false );
	m_grid8->EnableGridLines( true );
	m_grid8->EnableDragGridSize( false );
	m_grid8->SetMargins( 0, 0 );
	
	// Columns
	m_grid8->SetColSize( 0, 50 );
	m_grid8->SetColSize( 1, 43 );
	m_grid8->SetColSize( 2, 77 );
	m_grid8->SetColSize( 3, 77 );
	m_grid8->SetColSize( 4, 80 );
	m_grid8->EnableDragColMove( false );
	m_grid8->EnableDragColSize( true );
	m_grid8->SetColLabelSize( 30 );
	m_grid8->SetColLabelValue( 0, wxT("Hora") );
	m_grid8->SetColLabelValue( 1, wxT("Mesa") );
	m_grid8->SetColLabelValue( 2, wxT("Factura") );
	m_grid8->SetColLabelValue( 3, wxT("Total") );
	m_grid8->SetColLabelValue( 4, wxT("Fecha") );
	m_grid8->SetColLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Rows
	m_grid8->EnableDragRowSize( true );
	m_grid8->SetRowLabelSize( 0 );
	m_grid8->SetRowLabelAlignment( wxALIGN_CENTRE, wxALIGN_CENTRE );
	
	// Label Appearance
	
	// Cell Defaults
	m_grid8->SetDefaultCellAlignment( wxALIGN_LEFT, wxALIGN_TOP );
	bSizer36->Add( m_grid8, 1, wxALL|wxEXPAND, 5 );
	
	bSizer34->Add( bSizer36, 1, wxEXPAND, 5 );
	
	this->SetSizer( bSizer34 );
	this->Layout();
	
	this->Centre( wxBOTH );
	
	// Connect Events
	m_listBox1->Connect( wxEVT_COMMAND_LISTBOX_SELECTED, wxCommandEventHandler( MyDialog8::FechaElegida ), NULL, this );
	m_grid8->Connect( wxEVT_GRID_CELL_LEFT_DCLICK, wxGridEventHandler( MyDialog8::VerFac ), NULL, this );
}

MyDialog8::~MyDialog8()
{
	// Disconnect Events
	m_listBox1->Disconnect( wxEVT_COMMAND_LISTBOX_SELECTED, wxCommandEventHandler( MyDialog8::FechaElegida ), NULL, this );
	m_grid8->Disconnect( wxEVT_GRID_CELL_LEFT_DCLICK, wxGridEventHandler( MyDialog8::VerFac ), NULL, this );
	
}

MyDialog9::MyDialog9( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	
	wxBoxSizer* bSizer26;
	bSizer26 = new wxBoxSizer( wxVERTICAL );
	
	m_htmlWin1 = new wxHtmlWindow( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxHW_SCROLLBAR_AUTO );
	bSizer26->Add( m_htmlWin1, 1, wxALL|wxEXPAND, 5 );
	
	wxBoxSizer* bSizer27;
	bSizer27 = new wxBoxSizer( wxVERTICAL );
	
	m_button22 = new wxButton( this, wxID_ANY, wxT("Imprimir Factura"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer27->Add( m_button22, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxEXPAND, 5 );
	
	bSizer26->Add( bSizer27, 0, wxEXPAND, 5 );
	
	this->SetSizer( bSizer26 );
	this->Layout();
	
	this->Centre( wxBOTH );
	
	// Connect Events
	m_button22->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog9::onImprimir ), NULL, this );
}

MyDialog9::~MyDialog9()
{
	// Disconnect Events
	m_button22->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( MyDialog9::onImprimir ), NULL, this );
	
}
