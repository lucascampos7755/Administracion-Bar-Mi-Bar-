#include "Modificaciones.h"
#include "Productos.h"
#include "Bar.h"
#include <wx/icon.h>
#include "Funciones.h"
#include "FuncionesWx.h"
#include <wx/msgdlg.h>
#include <wx/valtext.h>

Modificaciones::Modificaciones(wxWindow *parent) : MyDialog2(parent) {
	SetIcon(wxIcon("logo.ico"));
	m_textCtrl6->SetValue(ToString(mi_bar->SugerirCodigo()));
	m_textCtrl9->SetFocus();
	wxTextValidator v(wxFILTER_NUMERIC);
	m_textCtrl6->SetValidator(v);
	m_textCtrl10->SetValidator(v);
}

void Modificaciones::Aceptar( wxCommandEvent& event )  {
	string busq = m_textCtrl6->GetValue().c_str();
	if((busq.substr(0,1)=="-") || busq==""){
		wxMessageBox("Ingrese un c�digo v�lido.","Error");
		m_textCtrl6->SetFocus();
		return;
	}
	if(mi_bar->YaExisteProd(busq)){
		wxMessageBox("Ese c�digo ya existe","Error");
		m_textCtrl6->SetFocus();
		return;
	}
	busq = m_textCtrl10->GetValue().c_str();
	if((busq.substr(0,1)=="-")||busq==""){
		wxMessageBox("Ingrese un precio v�lido.","Error");
		m_textCtrl10->SetFocus();
		return;
	}
	Productos e(\
		m_textCtrl9->GetValue().c_str(),\
		atoi(m_textCtrl6->GetValue().c_str()),\
		atoi(m_textCtrl10->GetValue().c_str()));
	
	mi_bar->AgregarProductos(e);
	mi_bar->Guardar();
	EndModal(1);
}


void Modificaciones::Cancelar( wxCommandEvent& event )  {
	EndModal(0);
}

Modificaciones::~Modificaciones() {
	EndModal(0);
}

void Modificaciones::BotonAgregar( wxCommandEvent& event )  {
	event.Skip();
}

void Modificaciones::BotonQuitar( wxCommandEvent& event )  {
	event.Skip();
}

void Modificaciones::ClickOnImprimir( wxCommandEvent& event )  {
	event.Skip();
}

