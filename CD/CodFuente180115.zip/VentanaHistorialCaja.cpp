#include "VentanaHistorialCaja.h"
#include <list>
#include "Bar.h"
#include "Funciones.h"
#include "Total.h"
#include <wx/msgdlg.h>
#include <wx/icon.h>
#include "FuncionesWx.h"
#include "VisorFacturas.h"
using namespace std;

VentanaHistorialCaja::VentanaHistorialCaja(wxWindow *parent) : MyDialog8(parent) {
	SetIcon(wxIcon("logo.ico"));
	m_listBox1->Clear();
	list<string> items = mi_bar->FechasHistorial();
	list<string>::iterator p=items.begin();
	while(p!=items.end()){
		m_listBox1->Append(*p);
		p++;		
	}
}

VentanaHistorialCaja::~VentanaHistorialCaja() {
	
}

void VentanaHistorialCaja::FechaElegida( wxCommandEvent& event )  {
	m_grid8->DeleteRows(0,m_grid8->GetNumberRows());
	string fecha = quitarformato(string(m_listBox1->GetString(m_listBox1->GetSelection()).mb_str()));
	InsertarEnGrilla(mi_bar->FiltrarCerradas(fecha));
}


void VentanaHistorialCaja::InsertarEnGrilla (list<q> l1) {
	list<q>::iterator p=l1.begin();
	int j=0;
	while(p!=l1.end()){
		m_grid8->InsertRows();
		j=m_grid8->GetGridCursorRow();
		m_grid8->SetCellValue(j,0,hora_f(p->hora));
		m_grid8->SetCellValue(j,1,ToString((p->numero_mesa+1)));
		m_grid8->SetCellValue(j,2,ToString((p->nrofac)));
		m_grid8->SetCellValue(j,3,ToString((p->totalfactura)));
		m_grid8->SetCellValue(j,4,formatofecha(ToString((p->fecha))));
		p++;
	}
}

void VentanaHistorialCaja::VerFac( wxGridEvent& event )  {
	string fecha;
	int fila=event.GetRow();
	string hora = horai(m_grid8->GetCellValue(fila,0).c_str());
	fecha = fechai(m_grid8->GetCellValue(fila,4).c_str());
	int ret = mi_bar->HacerFacturaHTML(fecha,hora);
	if(ret==0){
		VisorFacturas *viewer = new VisorFacturas(this);
		viewer->ShowModal();
	}
	else ErroresPrint(ret);
}

