#include "Bar.h"
#include <vector>
#include <algorithm>
#include "Productos.h"
#include "Mesas.h"
#include <cstring>
#include <cctype>
#include "Funciones.h"
#include <wx/msgdlg.h>
#include <climits>
#include <list>
#include <string>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
using namespace std;
Bar *mi_bar;
Bar::Bar(string nombreproductos,string neto){
	cerrada = false;
	nombre_archivoproductos=nombreproductos;
	nombre_archivomesas=neto;
	
	
	ifstream archi2(nombre_archivoproductos.c_str(),ios::binary|ios::ate);
	if (archi2.is_open()){
		int tamanio2=archi2.tellg();
		int tamanio2_=tamanio2/sizeof(stock);
		cantidad.resize(tamanio2_);
		archi2.seekg(0,ios::beg);
		for(int i=0;i<tamanio2_;i++){
			cantidad[i].leerproducto(archi2);
		}
		archi2.close();
	}
	ifstream archi3(nombre_archivomesas.c_str(),ios::binary|ios::ate);
	if (archi3.is_open()){
		int tamanio3=archi3.tellg();
		int tamanio3_=tamanio3/sizeof(q);
		total2.resize(tamanio3_);
		archi3.seekg(0,ios::beg);
		for(int i=0;i<tamanio3_;i++){
			total2[i].leerproducto2(archi3);
			if(!total2[i].devuelve_cerrado()) cerrada=false;
		}
		archi3.close();
	}
	
	consumo.resize(LeerMesasInicial());
	DesocuparTodas();
}
bool Bar::Guardar() {
	//Guarda los productos
	ofstream archi(nombre_archivoproductos.c_str(),ios::binary|ios::trunc);
	if (!archi.is_open()) return false;
	int cantidadproductos=CantidadDeProductos();
	for (int i=0;i<cantidadproductos;i++)
		cantidad[i].guardarproductos(archi);
	archi.close();
	//Guarda las facturas
	ofstream archi3(nombre_archivomesas.c_str(),ios::binary|ios::trunc);
	if (!archi3.is_open()) return false;
	for(int i=0;i<CantidadFacturas();i++) { 
		total2[i].guardarproductos2(archi3);
	}
	archi3.close();
	return true;
}

int Bar::CantidadDeProductos(){ return cantidad.size(); }
int Bar::CantidadDeMesas(){ return consumo.size(); }
void Bar::AgregarProductos(Productos &p){ cantidad.push_back (p); }
Productos &Bar::operator[](int i){ return cantidad[i]; }
void Bar::OrdenaAlf(){
	for(int i=0;i<CantidadDeProductos();i++){
		string a= cantidad[i].vernombre();
		int e=a.size();
		a[0]=toupper(a[0]);
		for(int t=1;t<e;t++){
			a[t]=tolower(a[t]);
		}
		cantidad[i].modificanombre(a);
	}
	vector<string>V;
	for(int i=0;i<CantidadDeProductos();i++){
		V.push_back(cantidad[i].vernombre());
	}
	sort(V.begin(),V.end());
	for(int i=0;i<CantidadDeProductos();i++){ 
		Productos aux;
		for(int o=i;o<CantidadDeProductos();o++){
			if(V[i]==cantidad[o].vernombre()){
				aux=cantidad[i];
				cantidad[i]=cantidad[o];
				cantidad[o]=aux;
			}
		}
	}
}
int Bar::Buscarpos(string nom){
	
	for(int i=0;i<CantidadDeProductos();i++){
		string a,b;
		a=nom;b=cantidad[i].vernombre();
		if (a==b){//comparo en minusculas
			return i;break;
		}
	}
	return -1;
}

void Bar::EliminarProd( int pos){
	cantidad.erase(cantidad.begin()+pos);
	
}

Bar::~Bar() {
	
}


int Bar::Buscarposc (int cod) {
	for(int i=0;i<CantidadDeProductos();i++) { 
		if(cantidad[i].devuelvecodigo()==cod) return i;
	}
	return -1;
}

int Bar::CantidadFacturas ( ) {
	return total2.size();
}

int Bar::GetNewFacCod(int cod){
	if (cod==0 || cod <0 || cod > INT_MAX){
		ifstream arch_i("factura");
		int last;
		arch_i>>last;
		arch_i.close();
		ofstream arch_o("factura",ios::trunc);
		arch_o<<++last;
		arch_o.close();
		return last;
	}
	return cod;
}

Total Bar::elemCaja (int i) {
	return total2[i];
}

bool Bar::CajaCerrada ( ) {
	return cerrada;
}

void Bar::AbrirCaja ( ) {
	cerrada = false;
}

void Bar::CerrarCaja ( ) {
	cerrada = true;
}

void Bar::CambiarCaja ( ) {
	if (cerrada) AbrirCaja(); 
	else{
		CerrarCaja();
		for(int i=0;i<total2.size();i++) { 
			if(!total2[i].devuelve_cerrado()){
				total2[i].cerrar();
			}
		}
		Guardar();
	}
}

string Bar::GetTotalUnFac ( ) {
	int count=0;
	for(int i=0;i<total2.size();i++) { 
		if(!total2[i].devuelve_cerrado()) count+=total2[i].devuelve_totalfactura();
	}
	return ToString(count);
}

list<string> Bar::FechasHistorial ( ) {
	list<string> l1;string aux;
	for(int i=0;i<total2.size();i++) { 
		if(total2[i].devuelve_cerrado()){
			aux = total2[i].devuelve_fcierre();
			if(find(l1.begin(),l1.end(),formatofecha(aux))==l1.end()){
				l1.push_back(formatofecha(aux));
			}
		}
	}
	reverse(l1.begin(),l1.end());
	return l1;
}

list<q> Bar::FiltrarCerradas (string fecha) {
	list<q> l1;q *aux = new q();
	for(int i=0;i<total2.size();i++) { 
		if(total2[i].devuelve_fcierre()==fecha){
			delete aux;
			aux = new q();
			aux->cerrado=total2[i].devuelve_cerrado();
			aux->fecha=total2[i].devuelve_fecha();
			strcpy(aux->fechacierre,total2[i].devuelve_fcierre().c_str());
			aux->hora=total2[i].devuelve_hora();
			aux->nrofac=total2[i].devuelve_nrofac();
			aux->numero_mesa=total2[i].devuelve_numeromesa();
			aux->totalfactura=total2[i].devuelve_totalfactura();
			l1.push_back(*aux);
		}
	}
	return l1;
}



int Bar::HacerFacturaHTML (string fecha, string hora) {
	return HacerFacturaHTML("facturas/"+fecha+hora+".txt");
}

int Bar::LeerMesasInicial ( ) {
	int val;
	ifstream archi("cmesas");
	archi>>val;
	if((val>48)||(val<0)) val=0;
	archi.close();
	return val;
}

void Bar::GuardarMesasInicial (int val) {
	ofstream archi("cmesas",ios::trunc);
	archi<<val;
	archi.close();
}

int Bar::AgregarMesa ( ) {
	consumo.push_back(Mesas());
	return consumo.size();
}

vector<Productos> Bar::BuscarPorNombre (string busq) {
	vector<Productos>v;Productos aux;
	for(int i=0;i<cantidad.size();i++) { 
		if(coincide(cantidad[i].vernombre(),busq)){
			aux.modificanombre(cantidad[i].vernombre());
			aux.modificaprecio(cantidad[i].devuelvePrecio());
			aux.modificacodigo(cantidad[i].devuelvecodigo());
			v.push_back(aux);
		}
		
	}
	return v;
}

vector<Productos> Bar::BuscarPorCodigo (string busq) {
	vector<Productos>v;Productos aux;
	
	for(int i=0;i<cantidad.size();i++) { 
		if(ToString(cantidad[i].devuelvecodigo())==busq){
			aux.modificanombre(cantidad[i].vernombre());
			aux.modificaprecio(cantidad[i].verprecio());
			aux.modificacodigo(cantidad[i].devuelvecodigo());
			v.push_back(aux);
		}
	}
	return v;
}

int Bar::GetTotalMesa (int table) {
	int items = consumo[table].cantitems();
	int cont = 0;
	int pos, codigo, cant, pre;
	for(int i=0;i<items;i++) { 
		codigo = consumo[table][i].first;
		pos = Buscarposc(codigo); if(pos==-1) continue;
		cant=consumo[table][i].second;
		pre=cantidad[pos].verprecio();
		cont+=cant*pre;
	}
	return cont;
}

vector<m> Bar::RecupMesa (int table) {
	vector<m> v;m aux;
	int pos,items,cant,pre,cont,codigo;
	items=consumo[table].cantitems();
	for(int i=0;i<items;i++) { 
		codigo = consumo[table][i].first;
		pos = Buscarposc(codigo); 
		if(pos==-1) continue;//Lo salteo
		cant=consumo[table][i].second;
		pre=cantidad[pos].verprecio();
		aux.codigo=ToString(consumo[table][i].first);
		aux.cantidad=ToString(cant);
		aux.descrip=cantidad[pos].vernombre();
		aux.precio=ToString(pre);
		aux.total=ToString(cant*pre);
		v.push_back(aux);
	}
	return v;
}

bool Bar::MesasSinFacturar ( ) {
	for(int i=0;i<consumo.size();i++) { 
		if (consumo[i].cantitems()!=0) return true;
	}
	return false;
}

void Bar::RemoveItem (int mesa, int i) {
	consumo[mesa].eliminaproducto(i);
}

int Bar::GetItemCount (int mesa) {
	return consumo[mesa].cantitems();
}

string Bar::CrearFactura (int table) {
	if(consumo[table].cantitems()==0) return "";
	string fechor,fech,hor;
	int fechi,hori;
	fechor=gethora();fech=fechor.substr(0,8);hor=fechor.substr(8);
	fechi=atoi(fech.c_str());hori=atoi(hor.c_str());
	string nombrearchivo="facturas/" +fechor+ ".txt";
	ofstream arch_factura(nombrearchivo.c_str(),ios::trunc);
	if (!arch_factura.is_open()) return "";
	int tot=GetTotalMesa(table);
	int fac=GetNewFacCod();
	Total item(table,fechi,tot,hori,fac,false);
	
	total2.push_back(item);//Inserto la nueva factura
	
	int pos,codigo,cantp,pre;
	m aux;
	int cant=GetItemCount(table);
	arch_factura<<fechor<<" Mesa "<<table+1<<" "<<fac<<endl;
	for(int i=0;i<cant;i++) { 
		codigo = consumo[table][i].first;
		cantp = consumo[table][i].second;
		pos = Buscarposc(codigo); 
		pre=cantidad[pos].verprecio();
		arch_factura<<i+1<<" "<<cantidad[pos].vernombre()+ " " + \
			ToString(cantp) + " " + ToString(pre) + " " + \
			ToString(cantp*pre)<<endl;
	}
	arch_factura<<GetTotalMesa(table);
	VaciarMesa(table);
	arch_factura.close();
	Guardar();
	return nombrearchivo;
}

void Bar::VaciarMesa (int table) {
	consumo[table].SetSize(0);
}

void Bar::AddItem (int table, int cod, int cant) {
	consumo[table].agregaproductos(cod,cant);
}

int Bar::HacerFacturaHTML (string nomarch) {
	ifstream archi(nomarch);
	if(!archi.is_open()) return 9900;
	archi.seekg(ios::end);
	if(archi.tellg()==0) return 9901;
	archi.seekg(ios::beg);
	string fech,mesa,detalle,detallesig,tabprop,nfac;
	tabprop="<table border=\"1\" style=\"width: 100%\">\n";
	ofstream salida("facturas/1.html",ios::trunc);
	if(!salida.is_open()) return 9903;
	archi>>fech;if(archi.eof()) return 9902;
	archi>>mesa; if(archi.eof()) return 9902;
	archi>>mesa;if(archi.eof()) return 9902;
	archi>>nfac;if(archi.eof()) return 9902;
	salida<<"<html>"<<endl<<"<body>"<<endl;
	salida<<"<center><img src=\"l1.png\"><br>"<<endl;
	salida<<"<table>\n"<<"<tr>\n<td></td>\n<td>"<<"<b>Cod. Factura: </b>"<<nfac<<"</td>\n</tr>\n";
	salida<<" <tr>\n<td><b>Fecha y hora: </b>"<<formatofecha(fech)<<"</td>\n<td>";
	salida<<" <div align=\"right\"><b>Mesa:</b> "<<mesa<<"</div></td>\n</tr>\n</table>\n";
	
	salida<<tabprop+"\n<tr>\n<th>Item</th>"<<endl<<"  <th>Nombre</th>"<<endl<<"  <th>Cantidad</th>"<<endl<<"  <th>Precio Unitario</th>"<<endl<<"  <th>Total</th>"<<endl<<"</tr>"<<endl;
	getline(archi,detalle);//linea de m�s
	vector<string>ult;int cont=1;
	getline(archi,detalle);//primer detalle
	while(true){
		getline(archi,detallesig);
		ult=GetLastX(detalle,3);
		salida<<"<tr>"<<endl;string a;
		salida<<"  <td>"<<cont<<"</td>"<<endl;//item
		salida<<"  <td>"<<ult[0].substr(3,ult[0].size())<<"</td>"<<endl;//nombre
		salida<<"  <td>"<<ult[1]<<"</td>"<<endl;//cantidad
		salida<<"  <td>"<<ult[2]<<"</td>"<<endl;//precio
		salida<<"  <td>"<<ult[3]<<"</td>"<<endl;//total
		salida<<"</tr>"<<endl;
		cont++;
		detalle=detallesig;
		if(archi.eof()){
			salida<<"</center><br><br><div align=\"right\">Total: $"<<detallesig;
			break;
		}
		
		
	}
	
	salida<<"</div>\n</table>"<<endl<<"</body>"<<endl<<"</html>";
	salida.close();
	return 0;
}

void Bar::OcuparMesa (int table) {
	consumo[table].Ocupar();
}

void Bar::DesocuparMesa (int table) {
	consumo[table].Desocupar();
}

bool Bar::MesasOcupadas ( ) {
	for(int i=0;i<consumo.size();i++) { 
		if (!MesaSinVentas(i)) return true;
	}
	return false;
}

void Bar::DesocuparTodas ( ) {
	for(int i=0;i<consumo.size();i++) { 
		consumo[i].Desocupar();
	}
}

bool Bar::MesaSinVentas (int table) {
	return (GetItemCount(table)==0);
}

int Bar::SugerirCodigo ( ) {
	vector<int> codigos;
	for(int i=0;i<CantidadDeProductos();i++) { 
		codigos.push_back(cantidad[i].devuelvecodigo());
	}
	int res;
	sort(codigos.begin(),codigos.end());
	if(codigos.size()==0) res = 1;
	else if(codigos.size()==1) {
		if (codigos[0]!=1) res = 1;
		else res = 2;
	}
	else{
		for(int i=0;i<codigos.size();i++) { 
			if(i==(codigos.size()-1)){
				res = codigos[i]+1;
				break;
			}
			if((codigos[i]+1)!=(codigos[i+1])){
				res = codigos[i]+1;
				break;
			}
		}
	}
	return res;
}

bool Bar::AbrirAyuda ( ) {
	//	system("  \"\"C:\\Program Files\\MiBar\\ayu.pdf\"  ");	
	ifstream dir("path");
	if(!dir.is_open()) return false;
	string path,ayu;
	getline(dir,path);
	replace(path.begin(),path.end(),'\\','/');
	ayu = "\"\""+ path + "/ayu.pdf"+"\"\"";
	system(ayu.c_str());
	return true;
}

bool Bar::YaExisteProd (string busq) {
	int num = atoi(busq.c_str());
	for(int i=0;i<CantidadDeProductos();i++) { 
		if (cantidad[i].devuelvecodigo() == num)
			return true;
	}
	return false;
}

