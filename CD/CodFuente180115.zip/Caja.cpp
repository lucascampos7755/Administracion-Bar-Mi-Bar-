#include "Caja.h"
#include "Bar.h"
#include "Total.h"
#include "Funciones.h"
#include <cstdlib>
#include "VisorFacturas.h"
#include <wx/msgdlg.h>
#include <wx/icon.h>
#include "FuncionesWx.h"
using namespace std;

Caja::Caja(wxWindow *parent) : MyDialog7(parent) {
	SetIcon(wxIcon("logo.ico"));
	m_button21->Disable();
	RefrescarTabla();
	if(!mi_bar->CajaCerrada()) m_button21->SetLabel("Cerrar Caja");
	else m_button21->SetLabel("Abrir Caja");
	m_button21->Enable();
}

Caja::~Caja() {
	
}

void Caja::VerFac( wxGridEvent& event )  {//doble clic en una factura (te lleva a una factura)
	string fecha;
	int fila=event.GetRow();
	string hora(m_grid4->GetCellValue(fila,0).c_str());
	hora=horai(hora);
	fecha = fechai(m_grid4->GetCellValue(fila,4).c_str());
	int ret = mi_bar->HacerFacturaHTML(fecha,hora);
	if(ret==0){
		VisorFacturas *viewer = new VisorFacturas(this);
		viewer->ShowModal();
	}
	else ErroresPrint(ret);
}


void Caja::ActualizarDatos ( int i ) {
	int j=m_grid4->GetNumberRows()-1;
	Total t = mi_bar->elemCaja(i);
	string hora = hora_f(t.devuelve_hora());
	m_grid4->SetCellValue(j,0,hora);
	m_grid4->SetCellValue(j,1,ToString(t.devuelve_numeromesa()+1));
	m_grid4->SetCellValue(j,2,ToString(t.devuelve_nrofac()));
	m_grid4->SetCellValue(j,3,"$"+ToString(t.devuelve_totalfactura()));
	m_grid4->SetCellValue(j,4,formatofecha(ToString(t.devuelve_fecha())));
}

void Caja::CambiarCaja( wxCommandEvent& event )  {
	if(!mi_bar->CajaCerrada()){
		int ans=wxMessageBox("�Est� seguro que desea cerrar la caja?","Cerrar Caja",wxYES_NO);
		if(ans==wxNO) return;
	}
	mi_bar->CambiarCaja();
	m_grid4->DeleteRows(0,m_grid4->GetNumberRows());
	if(mi_bar->CajaCerrada()) m_button21->SetLabel("Abrir Caja");
	else m_button21->SetLabel("Cerrar Caja");
	Close();
}

void Caja::RefrescarTabla ( ) {
	int cantidad = mi_bar->CantidadFacturas();
	for(int i=0;i<cantidad;i++){
		if(!mi_bar->elemCaja(i).devuelve_cerrado()){//Muestro las facturas no cerradas
			m_grid4->AppendRows();
			ActualizarDatos(i);
		}
	}
	
	m_textCtrl7->SetValue(mi_bar->GetTotalUnFac());
}

