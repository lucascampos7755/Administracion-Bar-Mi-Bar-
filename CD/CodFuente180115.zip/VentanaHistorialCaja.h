#ifndef VENTANAHISTORIALCAJA_H
#define VENTANAHISTORIALCAJA_H
#include "Ventanas.h"
#include <list>
#include "Total.h"
using namespace std;

class VentanaHistorialCaja : public MyDialog8 {
	
private:
	
protected:
	void VerFac( wxGridEvent& event ) ;
	void FechaElegida( wxCommandEvent& event ) ;
	
public:
	VentanaHistorialCaja(wxWindow *parent=NULL);
	~VentanaHistorialCaja();
	void InsertarEnGrilla(list<q> l1);
};

#endif

