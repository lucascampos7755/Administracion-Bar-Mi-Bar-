#ifndef MODIFICACIONES_H
#define MODIFICACIONES_H
#include "Ventanas.h"

class Modificaciones : public MyDialog2 {
	
private:
	
protected:
	void BotonAgregar( wxCommandEvent& event ) ;
	void BotonQuitar( wxCommandEvent& event ) ;
	void ClickOnImprimir( wxCommandEvent& event ) ;
	void Aceptar( wxCommandEvent& event ) ;
	void Cancelar( wxCommandEvent& event ) ;
	
public:
	Modificaciones(wxWindow *parent=NULL);
	~Modificaciones();
};

#endif

