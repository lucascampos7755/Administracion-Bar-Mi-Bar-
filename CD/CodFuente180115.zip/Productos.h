#ifndef PRODUCTOS_H
#define PRODUCTOS_H
#include <string>
using namespace std;
struct stock {//Struct similar a la clase, que uso para guardar en el binario.
	char nombre[25];
	int codigo,precio;
};
class Productos {//Una instancia de esta clase representa a un producto
private:
	string nomb;
	int codi,preci;
	
protected:
public:
	Productos(){}
	Productos( string nom,int cod,int prec);
	string vernombre(){ return nomb; }
	int verprecio(){ return preci; }
	void modificanombre(string nn){ nomb=nn; }
	void modificaprecio(int xx){ preci=xx; }
	void modificacodigo(int cc){ codi=cc; }
	void leerproducto(ifstream &stocks);
	void guardarproductos(ofstream &stocks);
	int devuelvecodigo(){ return codi; }
	string devuelveProducto(){ return nomb; }
	int devuelvePrecio(){ return preci;}
	
	~Productos();
};

#endif


