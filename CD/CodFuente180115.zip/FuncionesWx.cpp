#include "FuncionesWx.h"
#include <string>
#include "Bar.h"
#include <wx/html/htmprint.h>
#include <wx/msgdlg.h>
#include "Funciones.h"

#include <wx/valtext.h>
using namespace std;

bool PrintFac(string nomarch) {
	int ret = mi_bar->HacerFacturaHTML(nomarch);
	if(ret==0){
		wxHtmlEasyPrinting imprimir;
		imprimir.PrintFile("facturas/1.html");
		return true;
	}//Los siguientes mensajes de error los manejo ac� para que la clase sea independiente de wxWidgets
	ErroresPrint(ret);
	return false;
}

void ErroresPrint(int ret) {
	if (ret==9900) wxMessageBox("No se encontr� el archivo relacionado a la factura","Error");
	if (ret==9901) wxMessageBox("El archivo est� vac�o. No se puede visualizar","Error");
	if (ret==9902) wxMessageBox("Error de lectura del archivo. Compruebe que no lo est� usando otro\nprograma.","Error");
	if (ret==9903) wxMessageBox("No se pudo abrir el archivo de salida (html)","Error");
}

void ClearGrid(wxGrid & grid) {
	for(int i=0;i<grid.GetNumberRows();i++) { 
		if(grid.GetCellValue(i,0)==""&&grid.GetCellValue(i,1)=="") grid.DeleteRows(i);
	}
}
