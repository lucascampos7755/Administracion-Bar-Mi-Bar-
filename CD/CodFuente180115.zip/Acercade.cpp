#include "Acercade.h"
#include <wx/icon.h>
#include <wx/bitmap.h>

Acercade::Acercade(wxWindow *parent) : MyDialog5(parent) {
	SetIcon(wxIcon("logo.ico"));
}

Acercade::~Acercade() {
	
}

