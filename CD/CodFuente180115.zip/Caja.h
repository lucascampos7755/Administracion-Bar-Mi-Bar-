#ifndef CAJA_H
#define CAJA_H
#include "Ventanas.h"

class Caja : public MyDialog7 {
	
private:
	
protected:
	void CambiarCaja( wxCommandEvent& event ) ;
	void VerFac( wxGridEvent& event ) ;
	
public:
	Caja(wxWindow *parent=NULL);
	~Caja();
	void ActualizarDatos(int i);
	void RefrescarTabla();
};

#endif

