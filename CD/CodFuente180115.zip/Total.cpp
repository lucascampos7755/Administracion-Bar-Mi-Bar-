#include "Total.h"
#include "Funciones.h"
#include <cstdlib>
#include <wx/msgdlg.h>
#include <cstring>
using namespace std;

Total::Total(int n,int f,int p,int h,int nro,bool cerr) {
	numero_mesa=n;
	fecha=f;
	totalfactura=p;
	hora=h;
	nrofac=nro;
	cerrado=cerr;
	feccierre="";
	strcpy(fechacierre,feccierre.c_str());
}
Total::Total(){
	numero_mesa=0;
	fecha=0;
	totalfactura=0;
	hora=0;
	nrofac=0;
	cerrado=false;
	feccierre="";
	strcpy(fechacierre,feccierre.c_str());
}
int Total::devuelve_fecha(){
	return fecha;
}
int Total::devuelve_numeromesa(){
	return numero_mesa;
}
int Total::devuelve_totalfactura(){
	return totalfactura;
}
int Total::devuelve_hora(){
	return hora;
}

void Total::cambiafecha(int f){
	fecha=f;
}
void Total::cambiahora(int h1){
	hora=h1;
}
void Total::cambiatotal(int t1){
	totalfactura=t1;
}
void Total::cambianumeromesa(int n1){
	numero_mesa=n1;
}

void Total::leerproducto2(ifstream &Total){
	q p;
	Total.read((char*)&p,sizeof (q));
	fecha=p.fecha;
	hora=p.hora;
	numero_mesa=p.numero_mesa;
	totalfactura=p.totalfactura;
	nrofac=p.nrofac;
	cerrado=p.cerrado;
	strcpy(fechacierre,p.fechacierre);
	feccierre=fechacierre;
}
void Total::guardarproductos2(ofstream &Total){
	q g;
	g.fecha=fecha;
	g.hora=hora;
	g.totalfactura=totalfactura;
	g.numero_mesa=numero_mesa;
	g.nrofac=nrofac;
	g.cerrado=cerrado;
	strcpy(g.fechacierre,feccierre.c_str());
	Total.write((char*)&g, sizeof(g));
}



int Total::devuelve_nrofac ( ) {
	return nrofac;
}

void Total::cambianro (int t) {
	nrofac = t;
}

bool Total::devuelve_cerrado ( ) {
	return cerrado;
}

void Total::cerrar ( ) {
	cerrado = true;
	cambiafcierre(gethora());
}

void Total::abrir ( ) {
	cerrado = false;
}

string Total::devuelve_fcierre ( ) {
	return feccierre;
}

void Total::cambiafcierre (string t) {
	feccierre=t;
	strcpy(fechacierre,feccierre.substr(0,13).c_str());
}

q::q ( ) {
	numero_mesa=0;
	fecha=0;
	totalfactura=0;
	hora=0;
	nrofac=0;
	cerrado=false;
	string aux = "20011231235959";
	strcpy(fechacierre,aux.c_str());
}

