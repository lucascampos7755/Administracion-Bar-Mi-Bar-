#include "VentanaMesas.h"
#include <wx/grid.h>
#include "Bar.h"
#include "Funciones.h"
#include <fstream>
#include <string>
#include <regex>
#include <algorithm>
#include <iterator>
#include <vector>
#include <ios>
#include <ctime>
#include "VentanaAgregar.h"
#include <wx/dynarray.h>
#include <cstdlib>
#include <wx/msgdlg.h>
#include "Mesas.h"
#include "FuncionesWx.h"
#include <wx/icon.h>
using namespace std;

VentanaMesas::VentanaMesas(wxWindow *parent,const wxString nomarch): MyDialog21(parent) {
	SetIcon(wxIcon("logo.ico"));
	table=strint(nomarch.c_str());table--;
	if(!mi_bar->GetItemCount(table)) m_button18->SetLabel("Desocupar Mesa");
	Va_Precio->SetLabel("0");
	this->SetTitle(nomarch);
	Va_Precio->SetLabel(ToString(0));
	
	vector<m> res = mi_bar->RecupMesa(table);
	if (res.size()) Factura->AppendRows(res.size());
	for(int i=0;i<res.size();i++) { 
		Factura->SetCellValue(i,0,res[i].codigo);
		Factura->SetCellValue(i,1,res[i].descrip);
		Factura->SetCellValue(i,2,res[i].cantidad);
		Factura->SetCellValue(i,3,res[i].precio);
		Factura->SetCellValue(i,4,res[i].total);
	}
	
	ActualizarTotal();
	m_button20->SetFocus();
	ClearGrid(*Factura);
}

VentanaMesas::~VentanaMesas() {
	EndModal(0);
}

void VentanaMesas::BotonAgregar( wxCommandEvent& event )  {
	VentanaAgregar *AgregarMesa = new VentanaAgregar(this,table);
	AgregarMesa->ShowModal();
}

void VentanaMesas::BotonQuitar( wxCommandEvent& event )  {
	int val = mi_bar->GetItemCount(table);
	if(val){
		int sel = Factura->GetGridCursorRow();
		Factura->DeleteRows(sel);
		mi_bar->RemoveItem(table,sel);
		ActualizarTotal();
		if(val==1) m_button18->SetLabel("Desocupar Mesa");
	}
}

void VentanaMesas::ActualizarTotal ( ) {
	Va_Precio->SetLabel("0");
	string tot = ToString(mi_bar->GetTotalMesa(table));
	Va_Precio->SetLabel(tot);
}

void VentanaMesas::ClickOnImprimir( wxCommandEvent& event )  {
	if (mi_bar->MesaSinVentas(table)){
		mi_bar->DesocuparMesa(table);
		EndModal(1);
		return;
	}
	int ans=wxMessageBox("�Desea Imprimir la factura y desocupar la mesa?","Imprimir",wxYES_NO);
	if(ans==wxYES){
		string res = mi_bar->CrearFactura(table);
		if (res!="") {
			if(!PrintFac(res)) {
				wxMessageBox("Error desconocido al imprimir. Intente de nuevo.","Error");
				return;
			}
			Factura->DeleteRows(0,Factura->GetNumberRows());
			mi_bar->DesocuparMesa(table);
			EndModal(1);	
		}
		else{
			wxMessageBox("La factura no pudo ser creada. Intente de nuevo.","Error");
		}
	}
}

void VentanaMesas::Refrescar ( ) {
	Factura->DeleteRows(0,Factura->GetNumberRows());
	
	vector<m> res = mi_bar->RecupMesa(table);
	Factura->AppendRows(res.size());
	for(int i=0;i<res.size();i++) { 
		Factura->SetCellValue(i,0,res[i].codigo);
		Factura->SetCellValue(i,1,res[i].descrip);
		Factura->SetCellValue(i,2,res[i].cantidad);
		Factura->SetCellValue(i,3,res[i].precio);
		Factura->SetCellValue(i,4,res[i].total);
	}
	
	ActualizarTotal();
	m_button20->SetFocus();
}

