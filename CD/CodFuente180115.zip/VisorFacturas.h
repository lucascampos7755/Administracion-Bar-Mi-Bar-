#ifndef VISORFACTURAS_H
#define VISORFACTURAS_H
#include "Ventanas.h"

class VisorFacturas : public MyDialog9 {
	
private:
	
protected:
	void onImprimir( wxCommandEvent& event ) ;
	
public:
	VisorFacturas(wxWindow *parent=NULL);
	~VisorFacturas();
};

#endif

