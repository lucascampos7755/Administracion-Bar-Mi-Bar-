#ifndef TOTAL_H
#define TOTAL_H
#include <fstream>
using namespace std;
struct q{//Struct similar a la clase, que uso para guardar en el binario.
	int numero_mesa;
	int fecha;
	int totalfactura;
	int hora;
	int nrofac;
	bool cerrado;
	char fechacierre[15];
	q();
};
class Total {//Una instancia de esta clase representa a una factura. 
private:	 //Sus detalles no se guardan aqu�. S�lo el total de la venta.
	int numero_mesa;
	int fecha;
	int totalfactura;
	int hora;
	int nrofac;
	bool cerrado;
	char fechacierre[15];
	string feccierre;
protected:
public:
	Total();
	Total(int n,int f,int t,int h,int nro, bool cerr);
	int devuelve_fecha();
	int devuelve_numeromesa();
	int devuelve_hora();
	int devuelve_totalfactura();
	int devuelve_nrofac();
	string devuelve_fcierre();
	bool devuelve_cerrado();
	void cambiafecha(int f);
	void cambiahora(int h);
	void cambianumeromesa(int n);
	void cambiatotal(int t);
	void cambianro(int t);
	void cambiafcierre(string fnueva);
	void cerrar();
	void leerproducto2(ifstream &Total);
	void guardarproductos2(ofstream &Total);//Guarda registros de caja 
	void abrir();

};

#endif

