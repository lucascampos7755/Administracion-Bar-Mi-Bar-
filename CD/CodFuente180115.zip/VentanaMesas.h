#ifndef VENTANAMESAS_H
#define VENTANAMESAS_H
#include "Ventanas.h"
#include <string>
#include <vector>
using namespace std;
	
class VentanaMesas : public MyDialog21 {
private:
	friend class VentanaAgregar;
	void CargarFila(int i);
	wxString nombre;
	string archi;
protected:
	void tecla( wxKeyEvent& event ) ;
	void CerrarMesa( wxCloseEvent& event ) ;
	void BotonAgregar( wxCommandEvent& event ) ;
	void BotonQuitar( wxCommandEvent& event ) ;
	void ClickOnImprimir( wxCommandEvent& event ) ;
	int table;//numero de mesa (es un numero menor al que ve el usuario)
public:
	VentanaMesas(wxWindow *parent=NULL,const wxString nomarch="");
	~VentanaMesas();
	void ActualizarTotal();
	void Refrescar();
};

#endif

