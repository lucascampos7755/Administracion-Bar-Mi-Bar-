#include "VentanaPrincipal1.h"
#include "VentanaMesas.h"
#include "VentanaDeProductos.h"
#include "Ventanas.h"
#include <string>
#include <wx/gdicmn.h>
#include <wx/button.h>
#include "Funciones.h"
#include "Productos.h"
#include "Bar.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <wx/msgdlg.h>
#include <sstream>
#include "Acercade.h"
#include "EditMesas.h"
#include "VentanaHistorialCaja.h"
#include <wx/wx.h>
using namespace std;

wxSize VentanaPrincipal1::Heigt = wxSize(-1,30);

VentanaPrincipal1::VentanaPrincipal1(wxWindow *parent) : Frame0(parent){
	SetIcon(wxIconLocation("logo.ico"));
	B.resize(48,NULL);
	m_button7->SetBackgroundColour( *wxGREEN);
	B[0]=m_button7;
	for(int i=1;i<mi_bar->CantidadDeMesas();i++){
		m_button7 = new wxButton( this, wxID_ANY, "Mesa "+ToString(i+1), wxDefaultPosition, Heigt, 0 );
		B[i]=m_button7;
		m_button7->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler(VentanaPrincipal1::AbrirMesa) , NULL, this );
		gSizer1->Add( m_button7, 0, wxALIGN_CENTER_VERTICAL|wxALIGN_CENTER_HORIZONTAL|wxALL, 5 );
		m_button7->SetBackgroundColour( *wxGREEN);
	}
	Layout();
	Show();
}


VentanaPrincipal1::~VentanaPrincipal1() {
	B.clear();
}

void VentanaPrincipal1::AbrirMesa( wxCommandEvent& event )  {
	if (mi_bar->CajaCerrada()) {
		wxMessageBox("La caja est� cerrada. No se pueden realizar operaciones","Error al abrir mesa");
		return;
	}
	int r=event.GetId(),i=r;
	for( i=0;i<mi_bar->CantidadDeMesas();i++){
		if(B[i]->GetId()==r) break;
	}
	B[i]->SetBackgroundColour( *wxRED );
	mi_bar->OcuparMesa(i);
	VentanaMesas *VMesa = new VentanaMesas(this,B[i]->GetLabel());
	r=VMesa->ShowModal();
	if(r==1) {
		B[i]->SetBackgroundColour( *wxGREEN);
		mi_bar->DesocuparMesa(i);
	}
}

void VentanaPrincipal1::Agrega( wxCommandEvent& event )  {
	VentanaDeProductos *VProducto = new VentanaDeProductos(this);
	VProducto->ShowModal();
}

void VentanaPrincipal1::CerrarSesion( wxCommandEvent& event )  {
	//Si alguna de las mesas est� en sinfac, no se imprimi� la factura.
	wxColour color;bool salir=false;int ans;bool sinfac = false;bool abierta=false;bool ocup=false;
	sinfac=mi_bar->MesasSinFacturar();
	ocup=mi_bar->MesasOcupadas();
	if(mi_bar->GetTotalUnFac()!="0") abierta = true;
	if(abierta&&sinfac){
		ans=wxMessageBox("Hay mesas sin imprimir factura, y adem�s no se cerr� la caja.\nPara salir, al menos imprima las facturas de las mesas.","Salir");
		salir = false;
	}
	else if(abierta&&ocup){
		ans=wxMessageBox("No se cerr� la caja (hay facturas cargadas) y hay mesas ocupadas (sin pedidos cargados). �Salir Igual? La caja seguir� abierta.","Salir",wxYES_NO);
		if (ans==wxYES) salir = true;
	}
	else if(abierta){
		ans=wxMessageBox("No se cerr� la caja (hay facturas cargadas). �Desea salir igual? La caja seguir� abierta.","Salir",wxYES_NO);
		if(ans==wxYES) salir = true;
	}	
	else if(sinfac){
		ans=wxMessageBox("Hay mesas sin imprimir factura. Para salir, vaya a la mesa e imprima las facturas.","Salir");
		salir = false;
	}
	else if(ocup){
		ans=wxMessageBox("Hay mesas sin desocupar (sin pedidos cargados). �Salir igual?","Salir",wxYES_NO);
		if (ans==wxYES) salir = true;
	}
	else salir = true;
	if(salir) {
		this->Hide();
		this->Destroy(); //Close() no funciona!
	}
}

void VentanaPrincipal1::AgregarMesa( wxCommandEvent& event )  {
	int cant=mi_bar->CantidadDeMesas();
	if(cant<47) {
	m_button7 = new wxButton( this, wxID_ANY, wxT("Mesa "+ToString(cant+1)), wxDefaultPosition, Heigt, 0);
	m_button7->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( VentanaPrincipal1::AbrirMesa ), NULL, this );
	gSizer1->Add( m_button7, 0,wxALIGN_CENTER_VERTICAL|wxALIGN_CENTER_HORIZONTAL|wxALL, 5 );
	m_button7->SetBackgroundColour( *wxGREEN);
	B[cant]=m_button7;
	mi_bar->AgregarMesa();
	Layout();
	}
}

	

void VentanaPrincipal1::VerCaja( wxCommandEvent& event )  {
	Caja *cajita = new Caja(this);
	cajita->ShowModal();
}

void VentanaPrincipal1::VerHistorial( wxCommandEvent& event )  {
	VentanaHistorialCaja *hCaja = new VentanaHistorialCaja(this);
	hCaja->ShowModal();
}

void VentanaPrincipal1::VerAcercaDe( wxCommandEvent& event )  {
	Acercade *About = new Acercade(this);
	About->ShowModal();
}

void VentanaPrincipal1::OnCerrar( wxCloseEvent& event )  {
	wxCommandEvent b;
	CerrarSesion(b);
}

void VentanaPrincipal1::MesaMenos( wxCommandEvent& event )  {
	event.Skip();
}

void VentanaPrincipal1::onMesasEdit( wxMouseEvent& event )  {
	EditMesas *eMesas = new EditMesas(this);
	eMesas->ShowModal();
}


void VentanaPrincipal1::OnBotonCerrar (wxCommandEvent & event) {
	event.Skip();
}


void VentanaPrincipal1::onAyuda( wxCommandEvent& event )  {
	if(!mi_bar->AbrirAyuda()) 
		wxMessageBox("Hubo un problema al abrir el archivo de ayuda","Error");
}

