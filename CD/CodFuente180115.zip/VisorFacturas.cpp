#include "VisorFacturas.h"
#include <wx/html/htmprint.h>
#include <wx/icon.h>

VisorFacturas::VisorFacturas(wxWindow *parent) : MyDialog9(parent) {
	SetIcon(wxIcon("logo.ico"));
	m_htmlWin1->LoadPage("/facturas/1.html");
}

VisorFacturas::~VisorFacturas() {
	
}

void VisorFacturas::onImprimir( wxCommandEvent& event )  {
	wxHtmlEasyPrinting imprimir;
	imprimir.PrintFile("facturas/1.html");
}

