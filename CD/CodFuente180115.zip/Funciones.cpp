#include "Funciones.h"
#include <string>
#include <algorithm>
#include <cstring>
#include <sstream>
#include <ctime>
#include <wx/msgdlg.h>
#include <iomanip>
using namespace std;

string ToString(unint x){
	string txt = "";
	if(x==0) txt = "0";
	else {
		unint aux;
		while(x!=0){
			aux = x%10;
			txt += aux + zero;
			x/=10;
		}
		reverse(txt.begin(),txt.end());
	}
	txt+="\0";
	return txt;
}

string minusc(string str1) {
	transform(str1.begin(),str1.end(),str1.begin(),::tolower);
	return str1;
}

bool essubcadena(string s1, string s2){//true si encuentra a s2 en s1
	return (strstr(s1.c_str(),s2.c_str()));
}

bool coincide(string s1, string s2) {//pasa a minusculas las cadenas y devuelve true si s2 es subcadena de s1
	return essubcadena(minusc(s1),minusc(s2));
}


string twodig(int num) {
	stringstream a;
	if(num<10){
		a<<"0"<<num;
		return a.str();
	}
	a<<num;
	return a.str();
}


string hora_f(int h) {
	string a=ToString(h);
	if(h<10) a = "00000"+a;
	else if(h<100) a = "0000"+a;
	else if(h<1000) a = "000"+a;
	else if(h<10000) a = "00"+a;
	else if(h<100000) a = "0"+a;
	
	a.insert(4,":");
	a.insert(2,":");
	return a;
}

string gethora ( int formato) {
	time_t t1 = time(NULL);
	tm *ptm2 = localtime( &t1 );
	stringstream hora,aaaa,mes,dia,hh,mm,ss,cero;
	aaaa<<ptm2->tm_year+1900;
	mes<<ptm2->tm_mon+1;
	dia<<ptm2->tm_mday;
	hh<<ptm2->tm_hour;
	mm<<ptm2->tm_min;
	ss<<ptm2->tm_sec;
	if (formato == 1) {//formato 25/12/2014 - 23:59:00
		hora<<setfill('0')<<setw(2)<<dia.str()<<"/"<<setfill('0')<<setw(2)<<mes.str()<<"/"<<setfill('0')<<setw(2)<<aaaa.str(); //formato est�ndar (para mostrar)
		hora<<"-"<<setfill('0')<<setw(2)<<hh.str()<<":"<<setfill('0')<<setw(2)<<mm.str()<<":"<<setfill('0')<<setw(2)<<ss.str();
	}
	else if (formato == 0)//formato 20141225235900
		hora<<aaaa.str()<<setfill('0')<<setw(2)<<mes.str()<<setfill('0')<<setw(2)<<dia.str()<<setfill('0')<<setw(2)<<hh.str()<<setfill('0')<<setw(2)<<mm.str()<<setfill('0')<<setw(2)<<ss.str();
	else if(formato==2){//formato 20141225
		hora<<aaaa.str()<<setfill('0')<<setw(2)<<mes.str()<<setfill('0')<<setw(2)<<dia.str();
	}
	else if(formato==3){//formato 235900
		hora<<setfill('0')<<setw(2)<<hh.str()<<setfill('0')<<setw(2)<<mm.str()<<setfill('0')<<setw(2)<<ss.str();
	}
	return hora.str();
}

string horai(string hora) {
	remove(hora.begin(),hora.end(),':');
	hora.erase(6,hora.size());
	return hora;
}

string formatofecha(string fecha) {
//	if (fecha.size()!=14 || fecha.size()!=8) return fecha;
	if (fecha.size()!=8){
		fecha.insert(12,":");
		fecha.insert(10,":");
		fecha.insert(8," - ");
	}
	fecha.insert(6,"/");
	fecha.insert(4,"/");
	
	return fecha;
}

vector<string> GetLastX(string str, int cant) {
	vector<string>v;
	istringstream iss(str);
	
	do
		{
			string sub;
			iss >> sub;
			v.push_back(sub);
		} while (iss);
	
	if (!cant||cant>=v.size()) return v; //si quiero todo el vector o si la cantidad de palabras que quiero es mayor al tama�o del vector
	cant++;
	v.insert(v.begin(),"");
	for(int i=1;i<v.size()-cant;i++) { 
		v[0]+=" "+v[i];
	}
	v.erase(v.begin()+1,v.end()-cant);
	return v;
}

string fechai(string fecha) {//no testeado
	remove(fecha.begin(),fecha.end(),'/');
	fecha.erase(8,fecha.size());
	return fecha;
}


int strint(string fstring){
	fstring.erase(
		remove_if(fstring.begin(), fstring.end(), not1(ptr_fun(static_cast<int(*)(int)>(isdigit)))
		),
		fstring.end()
		);
	return atoi(fstring.c_str());
}

string quitarformato(string str) {
	remove(str.begin(),str.end(),'/');
	remove(str.begin(),str.end(),':');
	remove(str.begin(),str.end(),' ');
	remove(str.begin(),str.end(),'-');
	str.resize(14);
	return str;
}

