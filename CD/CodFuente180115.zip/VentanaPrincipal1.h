#ifndef VENTANAPRINCIPAL1_H
#define VENTANAPRINCIPAL1_H
#include "Ventanas.h"
#include <wx/gdicmn.h>
#include <vector>
#include <wx/button.h>
#include <wx/sizer.h>
using namespace std;



class VentanaPrincipal1 : public Frame0 {
	
private:
	static wxSize Heigt;
	vector<wxButton*> B;
	int cantmesas;
	
protected:
	void onAyuda( wxCommandEvent& event ) ;
	void onMesasEdit( wxMouseEvent& event ) ;
	void MesaMenos( wxCommandEvent& event ) ;
	void OnCerrar( wxCloseEvent& event ) ;
	void VerCaja( wxCommandEvent& event ) ;
	void VerHistorial( wxCommandEvent& event ) ;
	void VerAcercaDe( wxCommandEvent& event ) ;
	void AgregarMesa( wxCommandEvent& event ) ;
	void CerrarSesion( wxCommandEvent& event ) ;
	void Agrega( wxCommandEvent& event ) ;
	void AbrirMesa( wxCommandEvent& event ) ;
	void OnBotonCerrar( wxCommandEvent& event ) ;
public:
	VentanaPrincipal1(wxWindow *parent=NULL);
	~VentanaPrincipal1();
};

#endif

