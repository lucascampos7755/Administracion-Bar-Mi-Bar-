#ifndef FUNCIONES_H
#define FUNCIONES_H
#define zero 48
#include <string>
#include <vector>
using namespace std;
typedef unsigned int unint;

string ToString(unint x);

template<class Iterator> float Suma(Iterator begin, Iterator end){
	float sum = 0;
	while(begin != end ){
		sum += *begin;
		begin++;
	}
	return sum;
}

string minusc(string str1);//devuelve una versi�n en min�sculas

bool essubcadena(string s1, string s2);//true si encuentra a s2 en s1

bool coincide(string s1,string s2);

string twodig(int num);

string hora_f(int h);

string gethora (int formato=0);//Hora en formato AAAAMMDDHHMMSS

string horai(string hora); //Quita el formato 23:59:03 - > 235903

string formatofecha(string fecha); //Convierte fecha 20141225235959 a 25/12/2014 23:59:59

vector<string> GetLastX(string str,int cant=0); //Si el string es "hola como andas che" getlastx(str,2) devuelve {"hola como","andas","che") (cuenta de atras para adelante)

string fechai(string fecha); //Convierte 2014/12/31 a 20141231

int strint(string fstring); //Quito todos los no enteros de un string y devuelvo los enteros (la cadena puede contener hasta 9 numeros)

string quitarformato(string str); //Convierte de 2014/12/31 - 23:59:59 a 20141231235959

#endif
