#ifndef VENTANAAGREGAR_H
#define VENTANAAGREGAR_H
#include "Ventanas.h"
#include "VentanaMesas.h"

class VentanaAgregar : public MyDialog3 {
private:
protected:
	void SelProducto( wxCommandEvent& event ) ;
	void SelCodigo( wxCommandEvent& event ) ;
	void init( wxInitDialogEvent& event ) ;
	void tecla( wxKeyEvent& event ) ;
	void BusqEnter( wxCommandEvent& event ) ;
	void OnLeftDClick( wxGridEvent& event ) ;
	void Buscar (wxCommandEvent & event);
public:
	VentanaMesas *previa;
	int mesapadre;
	VentanaAgregar();
	VentanaAgregar(VentanaMesas *prev, int table);
	~VentanaAgregar();
	void AgregarProd ( int fila );
};

#endif

