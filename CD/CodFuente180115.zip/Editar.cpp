#include "Editar.h"
#include "Productos.h"
#include "Bar.h"
#include <wx/msgdlg.h>
#include <wx/icon.h>
#include <wx/valtext.h>

Editar::Editar(wxWindow *parent,int p) : MyDialog2(parent) {
	SetTitle("Modificar producto");
	SetIcon(wxIcon("logo.ico"));
	l=p;
	Productos &b=(*mi_bar)[p];
	char k[40];
	sprintf(k,"%d",b.devuelvecodigo());
	m_textCtrl6->SetValue(k);
	m_textCtrl6->Disable();
	m_textCtrl9->SetValue(b.devuelveProducto().c_str());
	m_textCtrl9->Disable();
	sprintf(k,"%d",b.devuelvePrecio());
	m_textCtrl10->SetValue(k);
	
	wxTextValidator v(wxFILTER_NUMERIC);
	m_textCtrl6->SetValidator(v);
	m_textCtrl10->SetValidator(v);
}

void Editar::Aceptar( wxCommandEvent& event )  {
	string busq=m_textCtrl10->GetValue().c_str();
	if(busq.substr(0,1)=="-"||busq==""){
		wxMessageBox("Ingrese un precio v�lido.","Error");
		m_textCtrl10->SetFocus();
		return;
	}
	Productos e(m_textCtrl9->GetValue().c_str(),\
		atoi(m_textCtrl6->GetValue().c_str()),\
		atoi(m_textCtrl10->GetValue().c_str()));
	(*mi_bar)[l]=e;
	mi_bar->Guardar();
	EndModal(1);
}

void Editar::Cancelar( wxCommandEvent& event )  {
	EndModal(0);
}

Editar::~Editar() {
	
}

void Editar::BotonAgregar( wxCommandEvent& event )  {
	event.Skip();
}

void Editar::BotonQuitar( wxCommandEvent& event )  {
	event.Skip();
}

void Editar::ClickOnImprimir( wxCommandEvent& event )  {
	event.Skip();
}

