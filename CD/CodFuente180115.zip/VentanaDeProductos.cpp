#include "VentanaDeProductos.h"
#include "Modificaciones.h"
#include "Bar.h"
#include <wx/msgdlg.h>
#include "Editar.h"
#include <wx/wx.h>
#include <cstdio>
#include <cstring>
#include <sstream>
#include "Funciones.h"
using namespace std;

VentanaDeProductos::VentanaDeProductos(wxWindow *parent) : MyDialog4(parent) {
	SetIcon(wxIcon("logo.ico"));
	m_radioBtn5->SetValue(true);
	int cantidad= mi_bar->CantidadDeProductos();
	m_grid30->AppendRows(cantidad);
	for(int i=0;i<cantidad;i++){
		ActualizarDatos(i);
	}
}

void VentanaDeProductos::AgregarProductos( wxCommandEvent& event )  {
	Modificaciones *modi = new Modificaciones(this);
	if(modi->ShowModal()==1){
		int e=mi_bar->CantidadDeProductos()-1;
		Productos &x=(*mi_bar)[e];
//		mi_bar->OrdenaAlf();
		mi_bar->Guardar();
		int f=mi_bar->Buscarpos(x.vernombre())-1;
		m_grid30->InsertRows(f);
		for(int i=0;i<mi_bar->CantidadDeProductos();i++){
			ActualizarDatos(i);
		};
		
	}
}

VentanaDeProductos::~VentanaDeProductos() {
	mi_bar->Guardar();
	EndModal(0);
}

void VentanaDeProductos::Modifica( wxCommandEvent& event )  {
	int r=m_grid30->GetGridCursorRow();
	Editar *edi=new Editar(this,r);
	if(edi->ShowModal()==1){
		ActualizarDatos(r);
	}
}

void VentanaDeProductos::ActualizarDatos(int i){
	Productos t=(*mi_bar)[i];
	char p[30];
	sprintf(p,"%d",t.devuelvecodigo());
	m_grid30->SetCellValue(i,0,p);
	sprintf(p,"%d",t.devuelvePrecio());
	m_grid30->SetCellValue(i,2,p);
	m_grid30->SetCellValue(i,1,t.devuelveProducto());
}

void VentanaDeProductos::Buscar( wxCommandEvent& event )  {
	m_grid30->DeleteRows(0,m_grid30->GetNumberRows());
	string busq=m_textCtrl4->GetValue().c_str();
	bool PorNombre = m_radioBtn5->GetValue();
	stringstream codi;
	vector<Productos>res;
	if(PorNombre || (!PorNombre && busq == "")) res = mi_bar->BuscarPorNombre(busq);
	else {
		if(busq.substr(0,1)=="-"||busq==""){
			wxMessageBox("Ingrese un n�mero v�lido","B�squeda incorrecta");
			res = mi_bar->BuscarPorNombre("");
		}
		else res = mi_bar->BuscarPorCodigo(busq);
	}
	if(!res.size()){
		wxMessageBox("No se encontr� ning�n producto","Buscar");
		res = mi_bar->BuscarPorNombre("");
	}
	m_grid30->AppendRows(res.size());
	for(int i=0;i<res.size();i++) {
		m_grid30->SetCellValue(i,0,ToString(res[i].devuelvecodigo()));
		m_grid30->SetCellValue(i,1,res[i].vernombre());
		m_grid30->SetCellValue(i,2,ToString(res[i].devuelvePrecio()));
	}
	m_textCtrl4->SetFocus();
}


void VentanaDeProductos::Eliminar( wxCommandEvent& event )  {
	if(mi_bar->MesasOcupadas()){
		wxMessageBox("No se pueden eliminar productos mientras haya mesas con productos cargados.","Error");
	}
	else{
		int t=m_grid30->GetGridCursorRow();
		string datos="\n  C�digo: "+string(m_grid30->GetCellValue(t,0).c_str())+"\n  Nombre: "+string(m_grid30->GetCellValue(t,1).c_str())+"\n  Precio: "+string(m_grid30->GetCellValue(t,2).c_str());
		int res=wxMessageBox("�Esta seguro que desea eliminar el producto?"+datos,"Eliminar producto",wxYES_NO);
		if(res==wxYES){
			m_grid30->DeleteRows(t,1);
			mi_bar->EliminarProd(t);
			mi_bar->Guardar();
		}
	}
	
}

void VentanaDeProductos::Enterlbl( wxCommandEvent& event )  {
	wxCommandEvent a;
	Buscar(a);
	m_textCtrl4->SetFocus();
}

void VentanaDeProductos::dblClic( wxGridEvent& event )  {
	int r=event.GetRow();
	Editar *edi=new Editar(this,r);
	if(edi->ShowModal()==1){
		ActualizarDatos(r);
	}
}

void VentanaDeProductos::SelProducto( wxCommandEvent& event )  {
	wxTextValidator v(wxFILTER_ALPHANUMERIC);
	m_textCtrl4->SetValidator(v);
	m_textCtrl4->SetMaxLength(25);
}

void VentanaDeProductos::SelCodigo( wxCommandEvent& event )  {
	wxTextValidator v(wxFILTER_NUMERIC);
	m_textCtrl4->SetValidator(v);
	m_textCtrl4->SetMaxLength(9);
}

