#ifndef MX_APPLICATION_H
#define MX_APPLICATION_H

#include <wx/app.h>

class mxApplication : public wxApp {
public:
	virtual bool OnInit();
};
IMPLEMENT_APP(mxApplication)
#endif
