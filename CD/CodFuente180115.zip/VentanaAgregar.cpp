#include "VentanaAgregar.h"
#include "Productos.h"
#include <algorithm>
#include <vector>
#include <fstream>
#include <wx/msgdlg.h>
#include <sstream>
#include <cstdlib>
#include <string>
#include "Bar.h"
#include "Funciones.h"
#include <wx/string.h>
#include <wx/icon.h>
#include <wx/valtext.h>
using namespace std;

VentanaAgregar::VentanaAgregar(): MyDialog3(NULL) {
	SetIcon(wxIcon("logo.ico"));
	m_radioBtn1->SetValue(true); //Por defecto la opci�n por nombre activada
	m_textCtrl11->SetFocus(); //Textbox de b�squeda
}

VentanaAgregar::VentanaAgregar (VentanaMesas *prev, int table):MyDialog3(NULL) {
	previa = prev;
	mesapadre=table;
	VentanaAgregar();
}

VentanaAgregar::~VentanaAgregar() {
}

void VentanaAgregar::Buscar (wxCommandEvent & event) {
	m_grid31->DeleteRows(0,m_grid31->GetNumberRows());//Borro las b�squedas previas
	//Los muestro en la grilla
	string busq=m_textCtrl11->GetValue().c_str(); //dato del textbox
	bool PorNombre = m_radioBtn1->GetValue();//true si la opci�n por nombre est� marcada
	stringstream codi;
	vector<Productos>res;
	if(PorNombre || (!PorNombre && busq == "")) res = mi_bar->BuscarPorNombre(busq);
	else {
		if(busq.substr(0,1)=="-"||busq==""){
			wxMessageBox("Ingrese un n�mero v�lido","B�squeda incorrecta");
			res = mi_bar->BuscarPorNombre("");
		}
		else res = mi_bar->BuscarPorCodigo(busq);
	}
	if(!res.size()){
		wxMessageBox("No se encontr� ning�n producto","Buscar");
		res = mi_bar->BuscarPorNombre("");
	}
	m_grid31->AppendRows(res.size());
	
	for(int i=0;i<res.size();i++) {
		m_grid31->SetCellValue(i,0,ToString(res[i].devuelvecodigo()));
		m_grid31->SetCellValue(i,1,res[i].vernombre());
	}
	
	m_textCtrl11->SetFocus();
}

void VentanaAgregar::OnLeftDClick( wxGridEvent& event )  {
	previa->m_button18->SetLabel("Imprimir Factura");
	int fila=event.GetRow();
	AgregarProd(fila);
}


void VentanaAgregar::BusqEnter( wxCommandEvent& event )  {
	wxCommandEvent a;
	Buscar(a);
	m_textCtrl11->SetFocus();
}


void VentanaAgregar::tecla( wxKeyEvent& event )  {
	if(event.GetKeyCode()==13) {
		AgregarProd(m_grid31->GetGridCursorRow());
	}
}


void VentanaAgregar::AgregarProd (int fila) {
	int codi=atoi(m_grid31->GetCellValue(fila,0).ToAscii());
	int cantidad=m_spinCtrl1->GetValue();
	
	mi_bar->AddItem(mesapadre,codi,cantidad);
	previa->Refrescar();
}

void VentanaAgregar::init( wxInitDialogEvent& event )  {
	wxCommandEvent a;
	Buscar(a);
}

void VentanaAgregar::SelProducto( wxCommandEvent& event )  {
	wxTextValidator v(wxFILTER_ALPHANUMERIC);
	m_textCtrl11->SetValidator(v);
	m_textCtrl11->SetMaxLength(25);
}

void VentanaAgregar::SelCodigo( wxCommandEvent& event )  {
	wxTextValidator v(wxFILTER_NUMERIC);
	m_textCtrl11->SetValidator(v);
	m_textCtrl11->SetMaxLength(9);
}

