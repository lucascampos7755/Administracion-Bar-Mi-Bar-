#ifndef VENTANADEPRODUCTOS_H
#define VENTANADEPRODUCTOS_H
#include "Ventanas.h"

class VentanaDeProductos : public MyDialog4 {
	
private:
	void ActualizarDatos(int i);
	
protected:
	void SelProducto( wxCommandEvent& event ) ;
	void SelCodigo( wxCommandEvent& event ) ;
	void dblClic( wxGridEvent& event ) ;
	void Enterlbl( wxCommandEvent& event ) ;
	void Eliminar( wxCommandEvent& event ) ;
	void Buscar( wxCommandEvent& event ) ;
	void Modifica( wxCommandEvent& event ) ;
	void AgregarProductos( wxCommandEvent& event ) ;
	
public:
	VentanaDeProductos(wxWindow *parent=NULL);
	~VentanaDeProductos();
};

#endif

