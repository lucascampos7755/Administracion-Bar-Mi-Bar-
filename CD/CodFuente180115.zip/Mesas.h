#ifndef MESAS_H
#define MESAS_H
#include <deque>
#include <string>
#include <fstream>
#include <vector>
using namespace std;
typedef pair<int,int> det_t;
struct m{//representa una linea de la factura
	string codigo;
	string descrip;
	string cantidad;
	string precio;
	string total;
};

class Mesas {//Una instancia de esta clase representa una mesa del bar (s�lo una).
private:
	string identi;
	vector<det_t> ventas;
	bool ocupada;
protected:
public:
	Mesas(){}
	Mesas(string identificacion);
	void agregaproductos(int cod,int cant);
	void eliminaproducto(int pos);
	int cantitems();
	det_t operator[](int i){return ventas[i];}
	void SetSize(int n);
	void Ocupar(){ocupada=true;}
	void Desocupar(){ocupada=false;}
	bool Ocupada(){return ocupada;}
	~Mesas();
};

#endif

